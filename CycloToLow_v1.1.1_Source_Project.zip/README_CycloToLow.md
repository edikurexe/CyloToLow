# CycloToLow (v1.1.0) — RideComp-Style Live Bike Computer + Strava Web Login

## Pembaruan v1.1.0
1. **Dual Theme (Light & Dark Mode)**: Tombol ganti tema langsung di bilah atas (`🌙` / `☀️`) dengan tema siang kontras tinggi ala RideComp/Wahoo dan tema malam AMOLED.
2. **Alur Layar RideComp**:
   - **Pre-Ride Dashboard**: Status baterai HP, kunci sinyal GPS, sensor fisik & BLE, profil sepeda (`Polygon Strattos`), pemuat rute GPX, dan tombol besar **START RIDE**.
   - **Active Ride Pages (`📊 DATA` & `🗺️ MAP`)**: Halaman grid angka besar (Speed, Distance, Moving Time, Avg/Max, Ascent/Grade, Heart Rate, Cadence, Est. Power) yang bisa diganti ke peta layar penuh dengan HUD melayang, lengkap dengan tombol **LAP**, **PAUSE/RESUME**, dan **FINISH**.
   - **Bottom Navigation Bar**: Tab **Ride**, **History** (riwayat aktivitas lokal), dan **Settings**.
