package id.cyclotolow.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class RideRecordingService : Service(), LocationListener {

    companion object {
        private const val CHANNEL_ID = "cyclotolow_live_ride"
        private const val NOTIF_ID = 701
    }

    inner class LocalBinder : Binder() {
        fun getService(): RideRecordingService = this@RideRecordingService
    }

    private val binder = LocalBinder()
    private lateinit var locationManager: LocationManager
    lateinit var sensorHub: PhoneSensorHub
        private set
    lateinit var bleManager: BleCyclingSensorManager
        private set

    private var wakeLock: PowerManager.WakeLock? = null
    private val uiTickerHandler = Handler(Looper.getMainLooper())

    var onSnapshotUpdated: ((LiveTelemetrySnapshot) -> Unit)? = null

    private var isRecording = false
    private var isManualPaused = false
    private var isAutoPaused = false
    private var lapCount = 1
    var sportType: String = "Ride"
    var totalSystemMassKg: Double = 72.0

    private val recordedPoints = ArrayList<RecordedTrackPoint>(4096)

    private var rideStartTimeMs = 0L
    private var lastTickMs = 0L
    private var totalDistanceMeters = 0.0
    private var movingTimeSec = 0.0
    private var elapsedTimeSec = 0.0

    private var currentSpeedMps = 0.0
    private var maxSpeedMps = 0.0

    private var smoothedElevationMeters = 0.0
    private var hasInitialElevation = false
    private var totalAscentMeters = 0.0
    private var totalDescentMeters = 0.0
    private var currentGradeFraction = 0.0

    private var lastAcceptedLocation: Location? = null
    private var latestRawLat: Double? = null
    private var latestRawLon: Double? = null
    private var latestBearing: Float = 0f
    private var latestAccuracy: Float = 999f

    private var lowSpeedStartMs = 0L
    private var wasPausedOnPrevPoint = false

    private var hrSum = 0L
    private var hrCount = 0
    private var maxHr = 0
    private var cadSum = 0L
    private var cadCount = 0
    private var maxCad = 0
    private var powerSum = 0L
    private var powerCount = 0
    private var maxPower = 0
    private var totalCalories = 0.0

    private val tickerRunnable = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (isRecording && lastTickMs > 0L) {
                val dtSec = ((now - lastTickMs) / 1000.0).coerceIn(0.0, 5.0)
                if (!isManualPaused) {
                    elapsedTimeSec += dtSec
                    if (!isAutoPaused) {
                        movingTimeSec += dtSec
                        val watts = estimateInstantPowerWatts(currentSpeedMps, currentGradeFraction)
                        val kcalPerSec = if (sportType == "Ride" && watts > 0) {
                            (watts / 1000.0) * 0.95
                        } else {
                            val met = when (sportType) {
                                "Run" -> 9.5
                                "Walk" -> 3.8
                                else -> 6.5
                            }
                            (met * 3.5 * (totalSystemMassKg - 10.0).coerceAtLeast(45.0)) / 12000.0
                        }
                        totalCalories += kcalPerSec * dtSec
                    }
                }
            }
            lastTickMs = now
            val snap = buildSnapshot()
            onSnapshotUpdated?.invoke(snap)
            if (isRecording) updateNotification(snap)
            uiTickerHandler.postDelayed(this, 1000L)
        }
    }

    @SuppressLint("MissingPermission")
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        sensorHub = PhoneSensorHub(this).apply { start() }
        bleManager = BleCyclingSensorManager(this)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CycloToLow::GpsRecordLock")

        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1.0f, this)
            locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { loc ->
                latestRawLat = loc.latitude
                latestRawLon = loc.longitude
                latestAccuracy = loc.accuracy
            }
        } catch (_: Exception) {}

        lastTickMs = System.currentTimeMillis()
        uiTickerHandler.post(tickerRunnable)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    @SuppressLint("MissingPermission")
    fun startNewRide() {
        recordedPoints.clear()
        totalDistanceMeters = 0.0
        movingTimeSec = 0.0
        elapsedTimeSec = 0.0
        currentSpeedMps = 0.0
        maxSpeedMps = 0.0
        hasInitialElevation = false
        totalAscentMeters = 0.0
        totalDescentMeters = 0.0
        currentGradeFraction = 0.0
        lastAcceptedLocation = null
        lowSpeedStartMs = 0L
        wasPausedOnPrevPoint = false
        lapCount = 1

        hrSum = 0; hrCount = 0; maxHr = 0
        cadSum = 0; cadCount = 0; maxCad = 0
        powerSum = 0; powerCount = 0; maxPower = 0
        totalCalories = 0.0

        rideStartTimeMs = System.currentTimeMillis()
        lastTickMs = rideStartTimeMs
        isRecording = true
        isManualPaused = false
        isAutoPaused = false

        if (wakeLock?.isHeld == false) {
            wakeLock?.acquire(12 * 3600 * 1000L)
        }
        startForeground(NOTIF_ID, buildNotification(buildSnapshot()))
    }

    fun markNextLap(): Int {
        if (isRecording) lapCount++
        return lapCount
    }

    fun toggleManualPause() {
        if (!isRecording) return
        isManualPaused = !isManualPaused
        if (isManualPaused) {
            currentSpeedMps = 0.0
            wasPausedOnPrevPoint = true
        }
    }

    fun stopAndFinalizeRide(): List<RecordedTrackPoint> {
        isRecording = false
        isManualPaused = false
        isAutoPaused = false
        currentSpeedMps = 0.0
        if (wakeLock?.isHeld == true) {
            try { wakeLock?.release() } catch (_: Exception) {}
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        return recordedPoints.toList()
    }

    fun getRecordedPointsSnapshot(): List<RecordedTrackPoint> = recordedPoints.toList()

    override fun onLocationChanged(location: Location) {
        val now = System.currentTimeMillis()
        latestRawLat = location.latitude
        latestRawLon = location.longitude
        latestAccuracy = location.accuracy
        if (location.hasBearing()) latestBearing = location.bearing
        if (location.hasAltitude()) {
            sensorHub.calibrateBarometerWithGpsAltitude(location.altitude, location.accuracy)
        }
        if (location.accuracy > 25f) return

        val bleWheelSpd = bleManager.getValidWheelSpeedMps()
        val gpsSpd = if (location.hasSpeed()) location.speed.toDouble() else 0.0
        val rawSpeedMps = if (bleWheelSpd > 0.2) bleWheelSpd else gpsSpd

        val stopThresholdMps = if (sportType == "Walk") 0.35 else 0.55
        if (rawSpeedMps < stopThresholdMps && !sensorHub.isDevicePhysicallyMoving) {
            if (lowSpeedStartMs == 0L) lowSpeedStartMs = now
            if (now - lowSpeedStartMs >= 4000L) {
                isAutoPaused = true
                currentSpeedMps = 0.0
                wasPausedOnPrevPoint = true
                return
            }
        } else {
            lowSpeedStartMs = 0L
            isAutoPaused = false
        }

        if (!isRecording || isManualPaused) {
            currentSpeedMps = if (isAutoPaused) 0.0 else rawSpeedMps
            return
        }

        val prevLoc = lastAcceptedLocation
        var segDist = 0.0
        if (prevLoc != null) {
            segDist = haversineMeters(prevLoc.latitude, prevLoc.longitude, location.latitude, location.longitude)
            if (segDist < 1.5 && rawSpeedMps < 0.8) return
            val dtSec = ((now - prevLoc.time) / 1000.0).coerceAtLeast(0.5)
            val computedSpd = segDist / dtSec
            currentSpeedMps = if (rawSpeedMps > 0.3) rawSpeedMps else computedSpd
        } else {
            currentSpeedMps = rawSpeedMps
        }

        if (currentSpeedMps > maxSpeedMps && currentSpeedMps < 35.0) maxSpeedMps = currentSpeedMps
        totalDistanceMeters += segDist
        lastAcceptedLocation = location

        val rawEle = sensorHub.baroAltitudeMeters
            ?: (if (location.hasAltitude()) location.altitude else smoothedElevationMeters)

        if (!hasInitialElevation) {
            smoothedElevationMeters = rawEle
            hasInitialElevation = true
        } else {
            val prevEle = smoothedElevationMeters
            smoothedElevationMeters = prevEle * 0.75 + rawEle * 0.25
            val dEle = smoothedElevationMeters - prevEle
            if (dEle > 0.35) totalAscentMeters += dEle
            else if (dEle < -0.35) totalDescentMeters += abs(dEle)
            if (segDist >= 5.0) currentGradeFraction = (dEle / segDist).coerceIn(-0.25, 0.25)
        }

        val hrNow = bleManager.getValidHeartRateBpm()
        if (hrNow > 0) {
            hrSum += hrNow; hrCount++
            if (hrNow > maxHr) maxHr = hrNow
        }

        val bleCad = bleManager.getValidCadenceRpm()
        val cadNow = when {
            bleCad > 0 -> bleCad
            sportType != "Ride" -> sensorHub.getCurrentStepCadenceSpm() / 2
            else -> 0
        }
        if (cadNow > 0) {
            cadSum += cadNow; cadCount++
            if (cadNow > maxCad) maxCad = cadNow
        }

        val wattsNow = estimateInstantPowerWatts(currentSpeedMps, currentGradeFraction)
        if (wattsNow > 0) {
            powerSum += wattsNow; powerCount++
            if (wattsNow > maxPower) maxPower = wattsNow
        }

        val tempNow = sensorHub.ambientTempC ?: estimateTemperatureByTimeAndAltitude(smoothedElevationMeters)

        recordedPoints.add(
            RecordedTrackPoint(
                latitude = location.latitude,
                longitude = location.longitude,
                elevationMeters = smoothedElevationMeters,
                timestampMs = now,
                cumulativeDistanceMeters = totalDistanceMeters,
                speedMps = currentSpeedMps,
                heartRateBpm = hrNow,
                cadenceRpm = cadNow,
                powerWatts = wattsNow,
                gradeFraction = currentGradeFraction,
                temperatureC = tempNow,
                isPauseResumePoint = wasPausedOnPrevPoint,
                lapNumber = lapCount
            )
        )
        wasPausedOnPrevPoint = false
    }

    private fun estimateInstantPowerWatts(speedMps: Double, grade: Double): Int {
        if (sportType != "Ride" || speedMps < 1.2) return 0
        val crr = 0.0045
        val cdA = 0.34
        val rho = 1.18
        val fGravity = totalSystemMassKg * 9.81 * sin(atan2(grade, 1.0))
        val fRolling = totalSystemMassKg * 9.81 * crr * cos(atan2(grade, 1.0))
        val fAero = 0.5 * rho * cdA * speedMps * speedMps
        val watts = ((fGravity + fRolling + fAero) * speedMps) / 0.97
        return watts.roundToInt().coerceIn(0, 1200)
    }

    private fun estimateTemperatureByTimeAndAltitude(altMeters: Double): Int {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val baseTemp = when (hour) {
            in 5..7 -> 24.0
            in 8..10 -> 28.0
            in 11..15 -> 32.0
            in 16..18 -> 29.0
            else -> 25.0
        }
        val lapse = (altMeters.coerceAtLeast(0.0) / 100.0) * 0.6
        return (baseTemp - lapse).roundToInt().coerceIn(10, 42)
    }

    fun buildSnapshot(): LiveTelemetrySnapshot {
        val avgSpdMps = if (movingTimeSec > 1.0) totalDistanceMeters / movingTimeSec else 0.0
        val tempNow = sensorHub.ambientTempC ?: estimateTemperatureByTimeAndAltitude(smoothedElevationMeters)
        val bleCad = bleManager.getValidCadenceRpm()
        val displayCad = when {
            bleCad > 0 -> bleCad
            sportType != "Ride" -> sensorHub.getCurrentStepCadenceSpm()
            else -> 0
        }

        return LiveTelemetrySnapshot(
            isRecording = isRecording,
            isPaused = isManualPaused,
            isAutoPaused = isAutoPaused,
            lapCount = lapCount,
            sportType = sportType,
            currentSpeedKmh = currentSpeedMps * 3.6,
            avgSpeedKmh = avgSpdMps * 3.6,
            maxSpeedKmh = maxSpeedMps * 3.6,
            totalDistanceMeters = totalDistanceMeters,
            movingTimeSec = movingTimeSec,
            elapsedTimeSec = elapsedTimeSec,
            currentElevationMeters = smoothedElevationMeters,
            totalAscentMeters = totalAscentMeters.roundToInt(),
            totalDescentMeters = totalDescentMeters.roundToInt(),
            currentGradePercent = currentGradeFraction * 100.0,
            currentHeartRateBpm = bleManager.getValidHeartRateBpm(),
            avgHeartRateBpm = if (hrCount > 0) (hrSum / hrCount).toInt() else 0,
            maxHeartRateBpm = maxHr,
            currentCadenceRpm = displayCad,
            avgCadenceRpm = if (cadCount > 0) (cadSum / cadCount).toInt() else 0,
            maxCadenceRpm = maxCad,
            currentPowerWatts = estimateInstantPowerWatts(currentSpeedMps, currentGradeFraction),
            avgPowerWatts = if (powerCount > 0) (powerSum / powerCount).toInt() else 0,
            maxPowerWatts = maxPower,
            totalCaloriesKcal = totalCalories.roundToInt(),
            temperatureC = tempNow,
            gpsAccuracyMeters = latestAccuracy,
            hasBarometer = sensorHub.hasBarometer,
            hasAmbientTemp = sensorHub.hasAmbientTemp,
            hasStepSensor = sensorHub.hasStepSensor,
            bleHrDeviceName = bleManager.connectedHrDeviceName,
            bleCscDeviceName = bleManager.connectedCscDeviceName,
            latestLat = latestRawLat,
            latestLon = latestRawLon,
            latestBearing = latestBearing,
            pointCount = recordedPoints.size
        )
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "CycloToLow GPS Recording", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(snap: LiveTelemetrySnapshot): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val statusText = String.format(Locale.US, "%.2f km • %.1f km/j • Avg %.1f km/j", snap.totalDistanceMeters / 1000.0, snap.currentSpeedKmh, snap.avgSpeedKmh)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_cyclo)
            .setContentTitle("CycloToLow (${snap.sportType}) • Lap ${snap.lapCount}")
            .setContentText(statusText)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(snap: LiveTelemetrySnapshot) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(snap))
    }

    override fun onDestroy() {
        uiTickerHandler.removeCallbacks(tickerRunnable)
        try { locationManager.removeUpdates(this) } catch (_: Exception) {}
        sensorHub.stop()
        bleManager.disconnect()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}
