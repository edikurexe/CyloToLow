package id.cyclotolow.app

data class RecordedTrackPoint(
    val latitude: Double,
    val longitude: Double,
    val elevationMeters: Double,
    val timestampMs: Long,
    val cumulativeDistanceMeters: Double,
    val speedMps: Double,
    val heartRateBpm: Int = 0,
    val cadenceRpm: Int = 0,
    val powerWatts: Int = 0,
    val gradeFraction: Double = 0.0,
    val temperatureC: Int = 28,
    val isPauseResumePoint: Boolean = false,
    val lapNumber: Int = 1
)

data class GuideWaypoint(
    val latitude: Double,
    val longitude: Double,
    val elevation: Double = 0.0
)

data class SavedRideHistoryItem(
    val id: String,
    val title: String,
    val sportType: String,
    val timestampMs: Long,
    val distanceKm: Double,
    val movingTimeSec: Double,
    val avgSpeedKmh: Double,
    val ascentMeters: Int,
    val uploadedToStrava: Boolean
)

data class LiveTelemetrySnapshot(
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val isAutoPaused: Boolean = false,
    val lapCount: Int = 1,
    val sportType: String = "Ride",
    val currentSpeedKmh: Double = 0.0,
    val avgSpeedKmh: Double = 0.0,
    val maxSpeedKmh: Double = 0.0,
    val totalDistanceMeters: Double = 0.0,
    val movingTimeSec: Double = 0.0,
    val elapsedTimeSec: Double = 0.0,
    val currentElevationMeters: Double = 0.0,
    val totalAscentMeters: Int = 0,
    val totalDescentMeters: Int = 0,
    val currentGradePercent: Double = 0.0,
    val currentHeartRateBpm: Int = 0,
    val avgHeartRateBpm: Int = 0,
    val maxHeartRateBpm: Int = 0,
    val currentCadenceRpm: Int = 0,
    val avgCadenceRpm: Int = 0,
    val maxCadenceRpm: Int = 0,
    val currentPowerWatts: Int = 0,
    val avgPowerWatts: Int = 0,
    val maxPowerWatts: Int = 0,
    val totalCaloriesKcal: Int = 0,
    val temperatureC: Int = 28,
    val gpsAccuracyMeters: Float = 999f,
    val hasBarometer: Boolean = false,
    val hasAmbientTemp: Boolean = false,
    val hasStepSensor: Boolean = false,
    val bleHrDeviceName: String = "",
    val bleCscDeviceName: String = "",
    val latestLat: Double? = null,
    val latestLon: Double? = null,
    val latestBearing: Float = 0f,
    val pointCount: Int = 0
)
