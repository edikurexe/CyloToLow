package id.cyclotolow.app

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

object FitAndGpxEncoder {

    private const val FIT_EPOCH_OFFSET_SEC = 631065600L
    private const val SEMICIRCLES_PER_DEGREE = 2147483648.0 / 180.0
    private val FIT_CRC_TABLE = intArrayOf(
        0x0000, 0xCC01, 0xD801, 0x1400, 0xF001, 0x3C00, 0x2800, 0xE401,
        0xA001, 0x6C00, 0x7800, 0xB401, 0x5000, 0x9C01, 0x8801, 0x4400
    )

    fun parseGuideGpx(inputStream: InputStream): List<GuideWaypoint> {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(inputStream, null)

        val raw = ArrayList<GuideWaypoint>(2048)
        var eventType = parser.eventType
        var currentTag: String? = null
        var lat: Double? = null
        var lon: Double? = null
        var ele = 0.0

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name?.lowercase() ?: ""
                    currentTag = name
                    if (name == "trkpt" || name == "rtept" || name == "wpt") {
                        lat = parser.getAttributeValue(null, "lat")?.toDoubleOrNull()
                        lon = parser.getAttributeValue(null, "lon")?.toDoubleOrNull()
                        ele = 0.0
                    }
                }
                XmlPullParser.TEXT -> {
                    if (currentTag == "ele") {
                        ele = parser.text?.trim()?.toDoubleOrNull() ?: 0.0
                    }
                }
                XmlPullParser.END_TAG -> {
                    val name = parser.name?.lowercase() ?: ""
                    if ((name == "trkpt" || name == "rtept" || name == "wpt") && lat != null && lon != null) {
                        raw.add(GuideWaypoint(lat, lon, ele))
                        lat = null
                        lon = null
                    }
                    currentTag = null
                }
            }
            eventType = parser.next()
        }

        if (raw.size <= 8000) return raw
        val step = raw.size.toDouble() / 8000.0
        val out = ArrayList<GuideWaypoint>(8002)
        for (i in 0 until 8000) {
            out.add(raw[(i * step).toInt().coerceIn(0, raw.size - 1)])
        }
        out.add(raw.last())
        return out
    }

    fun generateFitBinary(
        points: List<RecordedTrackPoint>,
        snap: LiveTelemetrySnapshot
    ): ByteArray {
        val body = ByteArrayOutputStream()
        val startFitSec = toFitTimestampSec(points.first().timestampMs)
        val endFitSec = toFitTimestampSec(points.last().timestampMs)
        val sportByte = when (snap.sportType) {
            "Ride" -> 2
            "Walk" -> 11
            else -> 1
        }

        writeDefMsg(body, 0, 0, listOf(
            3 to (4 to 140),
            1 to (2 to 132),
            2 to (2 to 132),
            4 to (4 to 134),
            0 to (1 to 0)
        ))
        writeDataHeader(body, 0)
        writeUint32LE(body, 3918472610L)
        writeUint16LE(body, 1)
        writeUint16LE(body, if (snap.sportType == "Ride") 3121 else 4315)
        writeUint32LE(body, startFitSec)
        body.write(4)

        writeDefMsg(body, 1, 21, listOf(
            253 to (4 to 134),
            0 to (1 to 0),
            1 to (1 to 0)
        ))
        writeDataHeader(body, 1)
        writeUint32LE(body, startFitSec)
        body.write(0)
        body.write(0)

        val hasHr = points.any { it.heartRateBpm > 0 }
        val hasCad = points.any { it.cadenceRpm > 0 }
        val recFields = mutableListOf(
            253 to (4 to 134),
            0 to (4 to 133),
            1 to (4 to 133),
            5 to (4 to 134),
            2 to (2 to 132),
            6 to (2 to 132),
            13 to (1 to 1)
        )
        if (hasHr) recFields.add(3 to (1 to 2))
        if (hasCad) recFields.add(4 to (1 to 2))
        writeDefMsg(body, 2, 20, recFields)

        for (i in points.indices) {
            val pt = points[i]
            val ptSec = toFitTimestampSec(pt.timestampMs)

            if (pt.isPauseResumePoint && i > 0) {
                val prevSec = toFitTimestampSec(points[i - 1].timestampMs)
                writeDataHeader(body, 1)
                writeUint32LE(body, prevSec + 1L)
                body.write(0)
                body.write(1)

                writeDataHeader(body, 1)
                writeUint32LE(body, ptSec)
                body.write(0)
                body.write(0)
            }

            writeDataHeader(body, 2)
            writeUint32LE(body, ptSec)
            writeInt32LE(body, (pt.latitude * SEMICIRCLES_PER_DEGREE).roundToInt())
            writeInt32LE(body, (pt.longitude * SEMICIRCLES_PER_DEGREE).roundToInt())
            writeUint32LE(body, (pt.cumulativeDistanceMeters * 100.0).roundToInt().toLong().coerceAtLeast(0L))
            val fitAlt = ((pt.elevationMeters + 500.0) * 5.0).roundToInt().coerceIn(0, 65534)
            writeUint16LE(body, fitAlt)
            val fitSpd = (pt.speedMps * 1000.0).roundToInt().coerceIn(0, 65534)
            writeUint16LE(body, fitSpd)
            body.write(pt.temperatureC.coerceIn(-40, 80) and 0xFF)
            if (hasHr) body.write(if (pt.heartRateBpm > 0) pt.heartRateBpm.coerceIn(30, 240) else 255)
            if (hasCad) body.write(if (pt.cadenceRpm > 0) pt.cadenceRpm.coerceIn(1, 240) else 255)
        }

        writeDataHeader(body, 1)
        writeUint32LE(body, endFitSec)
        body.write(0)
        body.write(1)

        writeDefMsg(body, 3, 18, listOf(
            253 to (4 to 134),
            2 to (4 to 134),
            7 to (4 to 134),
            8 to (4 to 134),
            9 to (4 to 134),
            11 to (2 to 132),
            14 to (2 to 132),
            15 to (2 to 132),
            22 to (2 to 132),
            23 to (2 to 132),
            5 to (1 to 0),
            6 to (1 to 0),
            16 to (1 to 2),
            17 to (1 to 2),
            18 to (1 to 2),
            19 to (1 to 2)
        ))
        writeDataHeader(body, 3)
        writeUint32LE(body, endFitSec)
        writeUint32LE(body, startFitSec)
        writeUint32LE(body, (snap.elapsedTimeSec * 1000.0).roundToInt().toLong().coerceAtLeast(1000L))
        writeUint32LE(body, (snap.movingTimeSec * 1000.0).roundToInt().toLong().coerceAtLeast(1000L))
        writeUint32LE(body, (snap.totalDistanceMeters * 100.0).roundToInt().toLong().coerceAtLeast(0L))
        writeUint16LE(body, snap.totalCaloriesKcal.coerceIn(0, 65534))
        writeUint16LE(body, ((snap.avgSpeedKmh / 3.6) * 1000.0).roundToInt().coerceIn(0, 65534))
        writeUint16LE(body, ((snap.maxSpeedKmh / 3.6) * 1000.0).roundToInt().coerceIn(0, 65534))
        writeUint16LE(body, snap.totalAscentMeters.coerceIn(0, 65534))
        writeUint16LE(body, snap.totalDescentMeters.coerceIn(0, 65534))
        body.write(sportByte)
        body.write(0)
        body.write(if (snap.avgHeartRateBpm > 0) snap.avgHeartRateBpm.coerceIn(30, 240) else 255)
        body.write(if (snap.maxHeartRateBpm > 0) snap.maxHeartRateBpm.coerceIn(30, 240) else 255)
        body.write(if (snap.avgCadenceRpm > 0) snap.avgCadenceRpm.coerceIn(1, 240) else 255)
        body.write(if (snap.maxCadenceRpm > 0) snap.maxCadenceRpm.coerceIn(1, 240) else 255)

        writeDefMsg(body, 4, 34, listOf(
            253 to (4 to 134),
            0 to (4 to 134),
            1 to (2 to 132),
            2 to (1 to 0),
            3 to (1 to 0),
            4 to (1 to 0)
        ))
        writeDataHeader(body, 4)
        writeUint32LE(body, endFitSec)
        writeUint32LE(body, (snap.movingTimeSec * 1000.0).roundToInt().toLong().coerceAtLeast(1000L))
        writeUint16LE(body, 1)
        body.write(0)
        body.write(26)
        body.write(1)

        val dataBytes = body.toByteArray()
        val header = ByteArrayOutputStream().apply {
            write(14)
            write(0x20)
            writeUint16LE(this, 2132)
            writeUint32LE(this, dataBytes.size.toLong())
            write(".FIT".toByteArray(Charsets.US_ASCII))
        }
        val headerNoCrc = header.toByteArray()
        writeUint16LE(header, computeFitCrc(headerNoCrc, 0, headerNoCrc.size))

        val fullNoCrc = ByteArrayOutputStream().apply {
            write(header.toByteArray())
            write(dataBytes)
        }.toByteArray()

        val finalOut = ByteArrayOutputStream().apply {
            write(fullNoCrc)
            writeUint16LE(this, computeFitCrc(fullNoCrc, 0, fullNoCrc.size))
        }
        return finalOut.toByteArray()
    }

    fun generateGpxXml(
        points: List<RecordedTrackPoint>,
        title: String,
        sportType: String
    ): String {
        val isoFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val sb = StringBuilder(points.size * 180 + 512)
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<gpx creator=\"CycloToLow Android\" version=\"1.1\" xmlns=\"http://www.topografix.com/GPX/1/1\" xmlns:gpxtpx=\"http://www.garmin.com/xmlschemas/TrackPointExtension/v1\">\n")
        sb.append("  <metadata><time>").append(isoFmt.format(Date(points.first().timestampMs))).append("</time></metadata>\n")
        sb.append("  <trk>\n")
        sb.append("    <name>").append(escapeXml(title)).append("</name>\n")
        sb.append("    <type>").append(sportType.lowercase()).append("</type>\n")
        sb.append("    <trkseg>\n")
        for (pt in points) {
            sb.append(String.format(Locale.US, "      <trkpt lat=\"%.7f\" lon=\"%.7f\">", pt.latitude, pt.longitude))
            sb.append(String.format(Locale.US, "<ele>%.1f</ele>", pt.elevationMeters))
            sb.append("<time>").append(isoFmt.format(Date(pt.timestampMs))).append("</time>")
            if (pt.heartRateBpm > 0 || pt.cadenceRpm > 0) {
                sb.append("<extensions><gpxtpx:TrackPointExtension>")
                if (pt.heartRateBpm > 0) sb.append("<gpxtpx:hr>").append(pt.heartRateBpm).append("</gpxtpx:hr>")
                if (pt.cadenceRpm > 0) sb.append("<gpxtpx:cad>").append(pt.cadenceRpm).append("</gpxtpx:cad>")
                sb.append("</gpxtpx:TrackPointExtension></extensions>")
            }
            sb.append("</trkpt>\n")
        }
        sb.append("    </trkseg>\n  </trk>\n</gpx>\n")
        return sb.toString()
    }

    private fun escapeXml(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun toFitTimestampSec(epochMs: Long): Long =
        ((epochMs / 1000L) - FIT_EPOCH_OFFSET_SEC).coerceAtLeast(1L)

    private fun writeDefMsg(
        out: ByteArrayOutputStream,
        localMsgNum: Int,
        globalMsgNum: Int,
        fields: List<Pair<Int, Pair<Int, Int>>>
    ) {
        out.write(0x40 or (localMsgNum and 0x0F))
        out.write(0)
        out.write(0)
        writeUint16LE(out, globalMsgNum)
        out.write(fields.size)
        for ((defNum, sizeAndType) in fields) {
            out.write(defNum)
            out.write(sizeAndType.first)
            out.write(sizeAndType.second)
        }
    }

    private fun writeDataHeader(out: ByteArrayOutputStream, localMsgNum: Int) {
        out.write(localMsgNum and 0x0F)
    }

    private fun writeUint16LE(out: ByteArrayOutputStream, value: Int) {
        out.write(value and 0xFF)
        out.write((value ushr 8) and 0xFF)
    }

    private fun writeInt32LE(out: ByteArrayOutputStream, value: Int) {
        out.write(value and 0xFF)
        out.write((value ushr 8) and 0xFF)
        out.write((value ushr 16) and 0xFF)
        out.write((value ushr 24) and 0xFF)
    }

    private fun writeUint32LE(out: ByteArrayOutputStream, value: Long) {
        out.write((value and 0xFFL).toInt())
        out.write(((value ushr 8) and 0xFFL).toInt())
        out.write(((value ushr 16) and 0xFFL).toInt())
        out.write(((value ushr 24) and 0xFFL).toInt())
    }

    private fun computeFitCrc(data: ByteArray, offset: Int, length: Int): Int {
        var crc = 0
        for (i in offset until (offset + length)) {
            val byteVal = data[i].toInt() and 0xFF
            var tmp = FIT_CRC_TABLE[crc and 0xF]
            crc = (crc ushr 4) and 0x0FFF
            crc = crc xor tmp xor FIT_CRC_TABLE[byteVal and 0xF]
            tmp = FIT_CRC_TABLE[crc and 0xF]
            crc = (crc ushr 4) and 0x0FFF
            crc = crc xor tmp xor FIT_CRC_TABLE[(byteVal ushr 4) and 0xF]
        }
        return crc
    }
}
