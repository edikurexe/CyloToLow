package id.cyclotolow.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class StravaWebLoginActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TARGET_URL = "extra_target_url"
        const val URL_STRAVA_LOGIN = "https://www.strava.com/login"
        const val URL_STRAVA_HR_CONSENT = "https://www.strava.com/settings/consent"
        const val CLEAN_MOBILE_CHROME_UA =
            "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    }

    private lateinit var webView: WebView
    private lateinit var tvUrlStatus: TextView
    private lateinit var progressBar: ProgressBar

    private class KeyboardEnabledWebView(context: Context) : WebView(context) {
        override fun onCheckIsTextEditor(): Boolean = true
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.clearFlags(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM
        )
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )

        val initialUrl = intent?.getStringExtra(EXTRA_TARGET_URL) ?: URL_STRAVA_LOGIN

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.parseColor("#1E293B"))
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvTitle = TextView(this).apply {
            text = if (initialUrl.contains("consent")) "Izin Data Kesehatan (HR)" else "Login Strava Web"
            textSize = 13.5f
            setTextColor(Color.WHITE)
            paint.isFakeBoldText = true
        }
        tvUrlStatus = TextView(this).apply {
            text = "Login Strava Gratis (Tanpa Limit API)"
            textSize = 10f
            setTextColor(Color.parseColor("#6EE7B7"))
            maxLines = 1
        }
        titleCol.addView(tvTitle)
        titleCol.addView(tvUrlStatus)

        val btnBackupLogin = Button(this).apply {
            text = "🔑 Opsi"
            textSize = 10f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#334155"))
            setPadding(14, 6, 14, 6)
            setOnClickListener { showWebLoginOptionsDialog() }
        }

        val spacer1 = View(this).apply { layoutParams = LinearLayout.LayoutParams(8, 1) }

        val btnOpenHrConsent = Button(this).apply {
            text = "❤️ HR"
            textSize = 10f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E11D48"))
            setPadding(14, 6, 14, 6)
            setOnClickListener {
                tvTitle.text = "Izin Data Kesehatan (HR)"
                tvUrlStatus.text = "Pilih 'Allow Access / Izinkan' pada Health-Related Data"
                webView.loadUrl(URL_STRAVA_HR_CONSENT)
            }
        }

        val spacer2 = View(this).apply { layoutParams = LinearLayout.LayoutParams(8, 1) }

        val btnSaveDone = Button(this).apply {
            text = "✓ Simpan"
            textSize = 10f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#10B981"))
            setPadding(16, 6, 16, 6)
            setOnClickListener {
                syncAndSaveCookies()
                Toast.makeText(
                    this@StravaWebLoginActivity,
                    "Sesi & Pengaturan Strava berhasil disimpan!",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
        }

        topBar.addView(titleCol)
        topBar.addView(btnBackupLogin)
        topBar.addView(spacer1)
        topBar.addView(btnOpenHrConsent)
        topBar.addView(spacer2)
        topBar.addView(btnSaveDone)
        root.addView(topBar)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 8)
        }
        root.addView(progressBar)

        webView = KeyboardEnabledWebView(this).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            requestFocus(View.FOCUS_DOWN)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                userAgentString = CLEAN_MOBILE_CHROME_UA
            }

            setOnTouchListener { v, event ->
                if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_UP) {
                    if (!v.hasFocus()) v.requestFocus()
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
                }
                false
            }

            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progressBar.progress = newProgress
                    progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val targetUrl = request?.url?.toString() ?: return false
                    if (targetUrl.startsWith("http://") || targetUrl.startsWith("https://")) {
                        view?.settings?.userAgentString = CLEAN_MOBILE_CHROME_UA
                        return false
                    }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    syncAndSaveCookies()

                    if (url != null) {
                        when {
                            url.contains("disallowed_useragent") -> {
                                tvUrlStatus.text = "Google OAuth diblokir WebView — Gunakan '🔑 Opsi'"
                                showGoogleOAuthBlockedFallbackDialog()
                            }
                            url.contains("/settings/consent") -> {
                                tvUrlStatus.text = "PENTING: Setel Health-Related Data = Allow Access!"
                            }
                            url.contains("/dashboard") || url.contains("/onboarding") || url.contains("/athlete") -> {
                                tvUrlStatus.text = "Login Berhasil! Klik '❤️ HR' lalu '✓ Simpan'"
                                StravaWebUploader.setWebLoggedIn(this@StravaWebLoginActivity, true)
                                Toast.makeText(
                                    this@StravaWebLoginActivity,
                                    "Login Berhasil! Ketuk '❤️ HR' untuk cek izin HR, lalu '✓ Simpan'.",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                            else -> tvUrlStatus.text = url
                        }
                    }
                }
            }

            loadUrl(initialUrl)
        }

        root.addView(
            webView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
        webView.requestFocus()
    }

    private fun syncAndSaveCookies() {
        try {
            val cm = CookieManager.getInstance()
            cm.flush()
            val rawCookie = cm.getCookie("https://www.strava.com") ?: ""
            if (rawCookie.isNotEmpty()) {
                StravaWebUploader.saveManualWebCookie(this, rawCookie)
            }
        } catch (_: Exception) {
        }
    }

    private fun showGoogleOAuthBlockedFallbackDialog() {
        AlertDialog.Builder(this)
            .setTitle("⚠️ Google Sign-In Dibatasi di WebView")
            .setMessage(
                "Google memblokir login OAuth di dalam WebView pada perangkat ini.

" +
                    "Solusi:
" +
                    "1. Login memakai Email & Password Strava langsung di form halaman ini.
" +
                    "2. Atau login di Chrome lalu tempel (Paste) cookie '_strava4_session'."
            )
            .setPositiveButton("📋 Tempel Cookie Manual") { _, _ -> showPasteCookieDialog() }
            .setNeutralButton("🌐 Buka di Chrome") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(URL_STRAVA_LOGIN)))
            }
            .setNegativeButton("Kembali ke Login Email") { _, _ -> webView.loadUrl(URL_STRAVA_LOGIN) }
            .show()
    }

    private fun showWebLoginOptionsDialog() {
        val options = arrayOf(
            "📋 Tempel Cookie Sesi Strava (_strava4_session) Manual",
            "🌐 Buka Strava Login di Browser Eksternal (Chrome)",
            "🔄 Muat Ulang Halaman Login Strava",
            "🚪 Logout / Hapus Semua Cookie Sesi Strava"
        )
        AlertDialog.Builder(this)
            .setTitle("🔑 Opsi Login & Sesi Web Strava")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showPasteCookieDialog()
                    1 -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(URL_STRAVA_LOGIN)))
                    2 -> webView.loadUrl(URL_STRAVA_LOGIN)
                    3 -> {
                        CookieManager.getInstance().removeAllCookies(null)
                        CookieManager.getInstance().flush()
                        StravaWebUploader.clearWebSession(this)
                        webView.loadUrl(URL_STRAVA_LOGIN)
                        Toast.makeText(this, "Sesi & cookie Strava telah dihapus.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun showPasteCookieDialog() {
        val input = EditText(this).apply {
            hint = "Tempel nilai _strava4_session atau seluruh string Cookie..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            setText(StravaWebUploader.getSavedWebCookie(this@StravaWebLoginActivity))
            setPadding(36, 28, 36, 28)
        }
        AlertDialog.Builder(this)
            .setTitle("📋 Input Cookie Sesi Strava")
            .setMessage("Salin nilai cookie '_strava4_session' dari www.strava.com di browser lalu tempel di bawah:")
            .setView(input)
            .setPositiveButton("Simpan & Pakai") { _, _ ->
                val raw = input.text.toString().trim()
                if (raw.isEmpty()) {
                    Toast.makeText(this, "Cookie tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val formatted = if (raw.contains("=")) raw else "_strava4_session=$raw"
                StravaWebUploader.saveManualWebCookie(this, formatted)

                val cm = CookieManager.getInstance()
                cm.setAcceptCookie(true)
                formatted.split(";").forEach { part ->
                    val trimmed = part.trim()
                    if (trimmed.contains("=")) {
                        cm.setCookie("https://www.strava.com", "$trimmed; Domain=.strava.com; Path=/")
                    }
                }
                cm.flush()

                Toast.makeText(this, "Cookie sesi Strava berhasil disimpan!", Toast.LENGTH_LONG).show()
                finish()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
