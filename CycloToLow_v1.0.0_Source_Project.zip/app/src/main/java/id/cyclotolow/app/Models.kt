package id.cyclotolow.app

data class RecordedTrackPoint(
    val latitude: Double,
    val longitude: Double,
    val elevationMeters: Double,
    val timestampMs: Long,
    val cumulativeDistanceMeters: Double,
    val speedMps: Double,
    val heartRateBpm: Int = 0,       // 0 jika tidak ada sensor BLE HR
    val cadenceRpm: Int = 0,         // dari BLE CSC atau Step Detector / Accelerometer
    val powerWatts: Int = 0,         // kalkulasi fisika nyata dari kecepatan + gradien + berat
    val gradeFraction: Double = 0.0,
    val temperatureC: Int = 28,
    val isPauseResumePoint: Boolean = false
)

data class GuideWaypoint(
    val latitude: Double,
    val longitude: Double,
    val elevation: Double = 0.0
)

data class LiveTelemetrySnapshot(
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val isAutoPaused: Boolean = false,
    val sportType: String = "Ride", // "Ride", "Run", "Walk"
    val currentSpeedKmh: Double = 0.0,
    val avgSpeedKmh: Double = 0.0,
    val maxSpeedKmh: Double = 0.0,
    val totalDistanceMeters: Double = 0.0,
    val movingTimeSec: Double = 0.0,
    val elapsedTimeSec: Double = 0.0,
    val currentElevationMeters: Double = 0.0,
    val totalAscentMeters: Int = 0,
    val totalDescentMeters: Int = 0,
    val currentGradePercent: Double = 0.0,
    val currentHeartRateBpm: Int = 0,
    val avgHeartRateBpm: Int = 0,
    val maxHeartRateBpm: Int = 0,
    val currentCadenceRpm: Int = 0,
    val avgCadenceRpm: Int = 0,
    val maxCadenceRpm: Int = 0,
    val currentPowerWatts: Int = 0,
    val avgPowerWatts: Int = 0,
    val maxPowerWatts: Int = 0,
    val totalCaloriesKcal: Int = 0,
    val temperatureC: Int = 28,
    val gpsAccuracyMeters: Float = 999f,
    val hasBarometer: Boolean = false,
    val hasAmbientTemp: Boolean = false,
    val hasStepSensor: Boolean = false,
    val bleHrDeviceName: String = "",
    val bleCscDeviceName: String = "",
    val latestLat: Double? = null,
    val latestLon: Double? = null,
    val latestBearing: Float = 0f,
    val pointCount: Int = 0
)
