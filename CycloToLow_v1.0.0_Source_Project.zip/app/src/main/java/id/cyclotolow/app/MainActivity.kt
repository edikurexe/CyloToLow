package id.cyclotolow.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.text.InputType
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var tvStravaBadge: TextView
    private lateinit var btnBleSensors: Button
    private lateinit var btnSportSwitch: Button

    private lateinit var tvGpsStatus: TextView
    private lateinit var tvHardwareSensorsInfo: TextView
    private lateinit var tvSpeedBig: TextView
    private lateinit var tvRideStateBanner: TextView

    private lateinit var tvDistanceVal: TextView
    private lateinit var tvMovingTimeVal: TextView
    private lateinit var tvAvgMaxVal: TextView
    private lateinit var tvElevGradeVal: TextView
    private lateinit var tvHeartRateVal: TextView
    private lateinit var tvCadenceKcalVal: TextView

    private lateinit var mapView: MapView
    private lateinit var btnKeepScreenOn: Button
    private lateinit var btnStartPauseRide: Button
    private lateinit var btnFinishRide: Button

    private var rideService: RideRecordingService? = null
    private var isBound = false
    private var keepScreenOn = true
    private var followUserMap = true
    private var currentSport = "Ride"

    private var livePolyline: Polyline? = null
    private var guidePolyline: Polyline? = null
    private var riderMarker: Marker? = null

    private var pendingExportPoints: List<RecordedTrackPoint> = emptyList()
    private var pendingExportSnapshot: LiveTelemetrySnapshot? = null

    private val pickGuideGpxLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) loadGuideGpxOverlay(uri)
    }

    private val exportFitLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val snap = pendingExportSnapshot
        if (uri != null && pendingExportPoints.size >= 2 && snap != null) {
            Thread {
                try {
                    val bytes = FitAndGpxEncoder.generateFitBinary(pendingExportPoints, snap)
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    runOnUiThread {
                        Toast.makeText(this, "File .FIT berhasil disimpan!", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, "Gagal simpan FIT: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }

    private val exportGpxLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/gpx+xml")
    ) { uri: Uri? ->
        if (uri != null && pendingExportPoints.size >= 2) {
            Thread {
                try {
                    val xml = FitAndGpxEncoder.generateGpxXml(
                        pendingExportPoints,
                        "CycloToLow $currentSport",
                        currentSport
                    )
                    contentResolver.openOutputStream(uri)?.use { it.write(xml.toByteArray(Charsets.UTF_8)) }
                    runOnUiThread {
                        Toast.makeText(this, "File .GPX berhasil disimpan!", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, "Gagal simpan GPX: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as RideRecordingService.LocalBinder
            rideService = binder.getService().apply {
                sportType = currentSport
                onSnapshotUpdated = { snap -> runOnUiThread { updateDashboardUi(snap) } }
            }
            isBound = true
            rideService?.let { updateDashboardUi(it.buildSnapshot()) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            rideService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        bindViews()
        setupMap()
        setupClickListeners()
        requestAllRequiredPermissions()

        val svcIntent = Intent(this, RideRecordingService::class.java)
        startService(svcIntent)
        bindService(svcIntent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun bindViews() {
        tvStravaBadge = findViewById(R.id.tvStravaBadge)
        btnBleSensors = findViewById(R.id.btnBleSensors)
        btnSportSwitch = findViewById(R.id.btnSportSwitch)

        tvGpsStatus = findViewById(R.id.tvGpsStatus)
        tvHardwareSensorsInfo = findViewById(R.id.tvHardwareSensorsInfo)
        tvSpeedBig = findViewById(R.id.tvSpeedBig)
        tvRideStateBanner = findViewById(R.id.tvRideStateBanner)

        tvDistanceVal = findViewById(R.id.tvDistanceVal)
        tvMovingTimeVal = findViewById(R.id.tvMovingTimeVal)
        tvAvgMaxVal = findViewById(R.id.tvAvgMaxVal)
        tvElevGradeVal = findViewById(R.id.tvElevGradeVal)
        tvHeartRateVal = findViewById(R.id.tvHeartRateVal)
        tvCadenceKcalVal = findViewById(R.id.tvCadenceKcalVal)

        mapView = findViewById(R.id.mapView)
        btnKeepScreenOn = findViewById(R.id.btnKeepScreenOn)
        btnStartPauseRide = findViewById(R.id.btnStartPauseRide)
        btnFinishRide = findViewById(R.id.btnFinishRide)
    }

    private fun setupMap() {
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.controller.setZoom(16.0)
        mapView.controller.setCenter(GeoPoint(-7.1507, 111.8817))

        livePolyline = Polyline().apply {
            outlinePaint.color = Color.parseColor("#FC4C02")
            outlinePaint.strokeWidth = 10f
        }
        mapView.overlays.add(livePolyline)

        riderMarker = Marker(mapView).apply {
            title = "Posisi Saat Ini"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        }
        mapView.overlays.add(riderMarker)
    }

    private fun setupClickListeners() {
        tvStravaBadge.setOnClickListener {
            showStravaAccountMenuDialog()
        }

        btnBleSensors.setOnClickListener {
            showBleSensorDialog()
        }

        btnSportSwitch.setOnClickListener {
            val sports = arrayOf("🚴 Bersepeda (Ride)", "🏃 Lari (Run)", "🚶 Jalan Kaki (Walk)")
            AlertDialog.Builder(this)
                .setTitle("Pilih Jenis Olahraga")
                .setItems(sports) { _, which ->
                    currentSport = when (which) {
                        1 -> "Run"
                        2 -> "Walk"
                        else -> "Ride"
                    }
                    btnSportSwitch.text = when (currentSport) {
                        "Run" -> "🏃 Run"
                        "Walk" -> "🚶 Walk"
                        else -> "🚴 Ride"
                    }
                    rideService?.sportType = currentSport
                }
                .show()
        }

        findViewById<Button>(R.id.btnCenterGps).setOnClickListener {
            followUserMap = true
            val snap = rideService?.buildSnapshot()
            if (snap?.latestLat != null && snap.latestLon != null) {
                mapView.controller.setZoom(16.5)
                mapView.controller.animateTo(GeoPoint(snap.latestLat, snap.latestLon))
            } else {
                Toast.makeText(this, "Menunggu kunci sinyal GPS...", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnLoadGuideGpx).setOnClickListener {
            val options = arrayOf(
                "📂 Muat File .GPX Panduan Rute di Peta",
                "🗑️ Hapus Garis Panduan Rute",
                "ℹ️ Info Sensor Aktif di HP Ini"
            )
            AlertDialog.Builder(this)
                .setTitle("Peta & Sensor Perangkat")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> pickGuideGpxLauncher.launch(arrayOf("*/*"))
                        1 -> {
                            guidePolyline?.let { mapView.overlays.remove(it) }
                            guidePolyline = null
                            mapView.invalidate()
                            Toast.makeText(this, "Garis panduan GPX dihapus.", Toast.LENGTH_SHORT).show()
                        }
                        2 -> {
                            val info = rideService?.sensorHub?.getAvailableSensorsSummary() ?: "GPS"
                            AlertDialog.Builder(this)
                                .setTitle("Sensor Perangkat Terdeteksi")
                                .setMessage("Sensor aktif yang dipakai CycloToLow:

• $info")
                                .setPositiveButton("OK", null)
                                .show()
                        }
                    }
                }
                .show()
        }

        btnKeepScreenOn.setOnClickListener {
            keepScreenOn = !keepScreenOn
            if (keepScreenOn) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                btnKeepScreenOn.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#E60F766E"))
                Toast.makeText(this, "Layar Tetap Menyala: AKTIF", Toast.LENGTH_SHORT).show()
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                btnKeepScreenOn.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#E6334155"))
                Toast.makeText(this, "Layar Tetap Menyala: MATI", Toast.LENGTH_SHORT).show()
            }
        }

        btnStartPauseRide.setOnClickListener {
            val svc = rideService ?: return@setOnClickListener
            val snap = svc.buildSnapshot()
            if (!snap.isRecording) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    requestAllRequiredPermissions()
                    return@setOnClickListener
                }
                livePolyline?.setPoints(emptyList())
                svc.startNewRide()
                Toast.makeText(this, "Perekaman GPS dimulai!", Toast.LENGTH_SHORT).show()
            } else {
                svc.toggleManualPause()
            }
            updateDashboardUi(svc.buildSnapshot())
        }

        btnFinishRide.setOnClickListener {
            val svc = rideService ?: return@setOnClickListener
            val snap = svc.buildSnapshot()
            if (!snap.isRecording) {
                Toast.makeText(this, "Belum ada sesi rekaman yang berjalan.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setTitle("Selesaikan & Simpan Aktivitas?")
                .setMessage(
                    String.format(
                        Locale.US,
                        "Jarak: %.2f km
Waktu Bergerak: %s
Avg Speed: %.1f km/j",
                        snap.totalDistanceMeters / 1000.0,
                        formatHms(snap.movingTimeSec),
                        snap.avgSpeedKmh
                    )
                )
                .setPositiveButton("Selesai & Upload") { _, _ ->
                    val finalSnap = svc.buildSnapshot()
                    val pts = svc.stopAndFinalizeRide()
                    updateDashboardUi(svc.buildSnapshot())
                    if (pts.size < 2) {
                        Toast.makeText(
                            this,
                            "Titik GPS terlalu sedikit (< 2 titik) untuk disimpan.",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        showPostRideUploadDialog(pts, finalSnap)
                    }
                }
                .setNegativeButton("Lanjut Gowes", null)
                .show()
        }
    }

    private fun updateDashboardUi(snap: LiveTelemetrySnapshot) {
        tvSpeedBig.text = String.format(Locale.US, "%.1f", snap.currentSpeedKmh)
        tvDistanceVal.text = String.format(Locale.US, "%.2f", snap.totalDistanceMeters / 1000.0)
        tvMovingTimeVal.text = formatHms(snap.movingTimeSec)
        tvAvgMaxVal.text = String.format(Locale.US, "%.1f / %.1f", snap.avgSpeedKmh, snap.maxSpeedKmh)
        tvElevGradeVal.text = String.format(Locale.US, "+%dm • %.1f%%", snap.totalAscentMeters, snap.currentGradePercent)

        tvHeartRateVal.text = if (snap.currentHeartRateBpm > 0) "${snap.currentHeartRateBpm} bpm" else "-- bpm"
        val cadUnit = if (snap.sportType == "Ride") "rpm" else "spm"
        val cadStr = if (snap.currentCadenceRpm > 0) "${snap.currentCadenceRpm} $cadUnit" else "--"
        tvCadenceKcalVal.text = "$cadStr • ${snap.totalCaloriesKcal} kcal"

        tvGpsStatus.text = when {
            snap.gpsAccuracyMeters <= 10f -> "🛰️ GPS: Akurat (${snap.gpsAccuracyMeters.roundToInt()}m)"
            snap.gpsAccuracyMeters <= 25f -> "🛰️ GPS: Cukup (${snap.gpsAccuracyMeters.roundToInt()}m)"
            else -> "🛰️ GPS: Mencari Satelit..."
        }
        val baroLabel = if (snap.hasBarometer) "${snap.currentElevationMeters.roundToInt()}m (Baro)" else "${snap.currentElevationMeters.roundToInt()}m"
        tvHardwareSensorsInfo.text = "Alt: $baroLabel • ${snap.temperatureC}°C"

        when {
            !snap.isRecording -> {
                btnStartPauseRide.text = "▶ MULAI REKAM"
                btnStartPauseRide.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#10B981"))
                tvRideStateBanner.text = "SIAP MEREKAM • TEKAN MULAI"
                tvRideStateBanner.setTextColor(Color.parseColor("#38BDF8"))
            }
            snap.isPaused -> {
                btnStartPauseRide.text = "▶ LANJUTKAN"
                btnStartPauseRide.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#3B82F6"))
                tvRideStateBanner.text = "⏸ DIJEDA MANUAL"
                tvRideStateBanner.setTextColor(Color.parseColor("#FBBF24"))
            }
            snap.isAutoPaused -> {
                btnStartPauseRide.text = "⏸ JEDA"
                btnStartPauseRide.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
                tvRideStateBanner.text = "⏸ AUTO-PAUSE (BERHENTI)"
                tvRideStateBanner.setTextColor(Color.parseColor("#FBBF24"))
            }
            else -> {
                btnStartPauseRide.text = "⏸ JEDA"
                btnStartPauseRide.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
                tvRideStateBanner.text = "● MEREKAM AKTIVITAS (${snap.pointCount} TITIK)"
                tvRideStateBanner.setTextColor(Color.parseColor("#34D399"))
            }
        }

        if (snap.latestLat != null && snap.latestLon != null) {
            val geo = GeoPoint(snap.latestLat, snap.latestLon)
            riderMarker?.position = geo
            if (followUserMap) {
                mapView.controller.animateTo(geo)
            }
        }

        val pts = rideService?.getRecordedPointsSnapshot() ?: emptyList()
        if (pts.size >= 2) {
            livePolyline?.setPoints(pts.map { GeoPoint(it.latitude, it.longitude) })
        }
        mapView.invalidate()
    }

    private fun showPostRideUploadDialog(points: List<RecordedTrackPoint>, snap: LiveTelemetrySnapshot) {
        pendingExportPoints = points
        pendingExportSnapshot = snap

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 24, 44, 12)
        }

        val defaultTitle = when (snap.sportType) {
            "Run" -> "Morning Run"
            "Walk" -> "Morning Walk"
            else -> "Afternoon Ride"
        }

        val tvStats = TextView(this).apply {
            text = String.format(
                Locale.US,
                "• Jarak: %.2f km
" +
                    "• Moving Time: %s (Total: %s)
" +
                    "• Avg / Max Speed: %.1f / %.1f km/j
" +
                    "• Elevation Gain: +%d m
" +
                    "• Heart Rate: Avg %d bpm (Max %d bpm)
" +
                    "• Kalori: %d kcal",
                snap.totalDistanceMeters / 1000.0,
                formatHms(snap.movingTimeSec),
                formatHms(snap.elapsedTimeSec),
                snap.avgSpeedKmh,
                snap.maxSpeedKmh,
                snap.totalAscentMeters,
                snap.avgHeartRateBpm,
                snap.maxHeartRateBpm,
                snap.totalCaloriesKcal
            )
            textSize = 12.5f
            setTextColor(Color.parseColor("#1E293B"))
        }

        val etTitle = EditText(this).apply {
            hint = "Judul Aktivitas Strava"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(defaultTitle)
        }

        val etDesc = EditText(this).apply {
            hint = "Deskripsi / Catatan (Opsional)"
            inputType = InputType.TYPE_CLASS_TEXT
        }

        container.addView(tvStats)
        container.addView(etTitle)
        container.addView(etDesc)

        val scroll = ScrollView(this).apply { addView(container) }

        AlertDialog.Builder(this)
            .setTitle("🏁 Aktivitas Selesai!")
            .setView(scroll)
            .setPositiveButton("🚀 Upload ke Strava") { _, _ ->
                val title = etTitle.text.toString().trim().ifEmpty { defaultTitle }
                val desc = etDesc.text.toString().trim()
                Toast.makeText(this, "⏳ Mengunggah ke Strava Web...", Toast.LENGTH_SHORT).show()
                StravaWebUploader.uploadRecordedRideAsync(
                    context = this,
                    points = points,
                    snapshot = snap,
                    title = title,
                    description = desc,
                    visibility = "everyone"
                ) { ok, msg ->
                    AlertDialog.Builder(this)
                        .setTitle(if (ok) "✅ Berhasil Masuk Strava!" else "⚠️ Gagal Upload")
                        .setMessage(msg)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            .setNeutralButton("💾 Simpan .FIT / .GPX") { _, _ ->
                val ts = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                AlertDialog.Builder(this)
                    .setTitle("Pilih Format File")
                    .setItems(arrayOf("Garmin .FIT (Direkomendasikan)", "Garmin .GPX")) { _, which ->
                        if (which == 0) exportFitLauncher.launch("CycloToLow_$ts.fit")
                        else exportGpxLauncher.launch("CycloToLow_$ts.gpx")
                    }
                    .show()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun showStravaAccountMenuDialog() {
        val options = arrayOf(
            "🌐 Login Strava Gratis (Web Login / Paste Cookie)",
            "❤️ Buka Pengaturan Izin Heart Rate (HR) Strava",
            "🚪 Logout Sesi Strava"
        )
        AlertDialog.Builder(this)
            .setTitle("Akun Strava Web (Gratis)")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, StravaWebLoginActivity::class.java))
                    1 -> {
                        val intent = Intent(this, StravaWebLoginActivity::class.java).apply {
                            putExtra(StravaWebLoginActivity.EXTRA_TARGET_URL, StravaWebLoginActivity.URL_STRAVA_HR_CONSENT)
                        }
                        startActivity(intent)
                    }
                    2 -> {
                        StravaWebUploader.clearWebSession(this)
                        refreshStravaBadge()
                        Toast.makeText(this, "Sesi Strava dihapus.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun showBleSensorDialog() {
        val ble = rideService?.bleManager ?: return
        if (!ble.isBluetoothAvailable()) {
            Toast.makeText(this, "Aktifkan Bluetooth di HP terlebih dahulu!", Toast.LENGTH_LONG).show()
            return
        }
        val foundList = mutableListOf<BleDiscoveredDevice>()
        val labels = mutableListOf<String>()

        val dialogBuilder = AlertDialog.Builder(this)
            .setTitle("📡 Memindai Sensor BLE (HR / Cadence)...")
            .setMessage("Pastikan sensor HR Strap atau Cadence Sensor aktif/berputar.")
            .setNegativeButton("Tutup") { _, _ -> ble.stopScan() }

        if (ble.connectedHrDeviceName.isNotEmpty() || ble.connectedCscDeviceName.isNotEmpty()) {
            dialogBuilder.setNeutralButton("Putuskan Sensor") { _, _ ->
                ble.disconnect()
                Toast.makeText(this, "Sensor BLE diputuskan.", Toast.LENGTH_SHORT).show()
            }
        }

        val scanDialog = dialogBuilder.show()

        ble.startScan(
            onDeviceFound = { dev ->
                foundList.add(dev)
                labels.add("${dev.name} • ${dev.typeLabel}")
                scanDialog.dismiss()
                AlertDialog.Builder(this)
                    .setTitle("Pilih Sensor BLE (${foundList.size} ditemukan)")
                    .setItems(labels.toTypedArray()) { _, idx ->
                        ble.connectToDevice(foundList[idx].device) { status ->
                            Toast.makeText(this, status, Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Batal") { _, _ -> ble.stopScan() }
                    .show()
            },
            onScanFinished = {
                if (foundList.isEmpty() && scanDialog.isShowing) {
                    scanDialog.setTitle("Tidak Ada Sensor BLE Ditemukan")
                    scanDialog.setMessage("Coba putar crank sepeda atau basahi strap HR lalu pindai ulang.")
                }
            }
        )
    }

    private fun loadGuideGpxOverlay(uri: Uri) {
        Thread {
            try {
                val wps = contentResolver.openInputStream(uri)?.use {
                    FitAndGpxEncoder.parseGuideGpx(it)
                } ?: emptyList()
                runOnUiThread {
                    if (wps.size < 2) {
                        Toast.makeText(this, "File GPX tidak valid.", Toast.LENGTH_SHORT).show()
                    } else {
                        guidePolyline?.let { mapView.overlays.remove(it) }
                        guidePolyline = Polyline().apply {
                            outlinePaint.color = Color.parseColor("#8038BDF8")
                            outlinePaint.strokeWidth = 8f
                            setPoints(wps.map { GeoPoint(it.latitude, it.longitude) })
                        }
                        mapView.overlays.add(0, guidePolyline)
                        mapView.controller.animateTo(GeoPoint(wps.first().latitude, wps.first().longitude))
                        mapView.invalidate()
                        Toast.makeText(this, "Panduan rute GPX dimuat (${wps.size} titik)!", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Gagal muat GPX: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun refreshStravaBadge() {
        if (StravaWebUploader.isWebSessionAvailable(this)) {
            tvStravaBadge.text = "🟢 Strava Web Terhubung"
            tvStravaBadge.setTextColor(Color.parseColor("#6EE7B7"))
        } else {
            tvStravaBadge.text = "🔴 Login Strava Gratis"
            tvStravaBadge.setTextColor(Color.parseColor("#FCA5A5"))
        }
    }

    private fun formatHms(secDouble: Double): String {
        val total = secDouble.roundToInt().coerceAtLeast(0)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    private fun requestAllRequiredPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            perms.add(Manifest.permission.ACTIVITY_RECOGNITION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 202)
        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        refreshStravaBadge()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        if (isBound) {
            unbindService(serviceConnection)
            isBound = false
        }
        super.onDestroy()
    }
}
