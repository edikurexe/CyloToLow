# CycloToLow (v1.0.0) — Live GPS & Sensor Bike Computer + Strava Web Login

## Fitur Utama
1. **Strava Web Session Login (`StravaWebLoginActivity` + `StravaWebUploader`)**:
   - Mengunggah rekaman aktivitas langsung ke akun Strava gratis menggunakan sesi cookie web (`_strava4_session`) tanpa terkena batasan kuota OAuth API 403.
   - Dilengkapi User-Agent Chrome Mobile bersih + opsi cadangan *Paste Cookie* & izin *Health-Related Data (HR)*.
2. **Multi-Sensor HP Universal (`PhoneSensorHub`)**:
   - Otomatis mendeteksi dan memanfaatkan sensor yang ada pada perangkat Android merek apa pun: **GPS**, **Barometer (`TYPE_PRESSURE`)** untuk ketinggian & gradien tanjakan presisi, **Ambient Temperature**, **Step Detector (`TYPE_STEP_DETECTOR`)** untuk cadence lari/jalan, **Linear Acceleration / Accelerometer** untuk deteksi gerakan fisik & auto-pause instan, serta **Rotation Vector** untuk kompas arah hadap.
3. **Koneksi Bluetooth Low Energy (`BleCyclingSensorManager`)**:
   - Mendukung sensor eksternal standar BLE **Heart Rate (`0x180D`)** dan **Cycling Speed & Cadence (`0x1816`)**.
4. **Foreground GPS Recording (`RideRecordingService`)**:
   - Tetap merekam koordinat, jarak, kecepatan, dan elevasi meskipun layar ponsel dimatikan.
5. **Ekspor `.FIT` & `.GPX` + Panduan Rute GPX**:
   - Menyimpan rekaman dalam format biner Garmin `.FIT` atau `.GPX`, serta mendukung pemuatan file `.GPX` sebagai garis panduan rute di peta.
