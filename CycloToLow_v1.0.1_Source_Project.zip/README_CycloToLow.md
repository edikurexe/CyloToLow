# CycloToLow (v1.0.1) — Live GPS & Sensor Bike Computer + Strava Web Login

## Perbaikan v1.0.1
- Perbaikan karakter escape `\n` dan `\"` pada `FitAndGpxEncoder.kt`, `MainActivity.kt`, `StravaWebLoginActivity.kt`, dan `StravaWebUploader.kt`.
- Perbaikan tipe non-null `Polyline` saat memuat garis panduan GPX di `MainActivity.kt`.
