package id.cyclotolow.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.Executors

object StravaWebUploader {

    private const val PREFS_NAME = "cyclotolow_strava_prefs"
    private const val KEY_WEB_LOGGED_IN = "web_logged_in"
    private const val KEY_MANUAL_WEB_COOKIE = "manual_web_cookie"

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun setWebLoggedIn(context: Context, loggedIn: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_WEB_LOGGED_IN, loggedIn)
            .apply()
    }

    fun saveManualWebCookie(context: Context, cookieHeader: String) {
        val clean = cookieHeader.trim()
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_MANUAL_WEB_COOKIE, clean)
            .putBoolean(KEY_WEB_LOGGED_IN, clean.isNotEmpty())
            .apply()
    }

    fun getSavedWebCookie(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_MANUAL_WEB_COOKIE, "") ?: ""

    fun clearWebSession(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .remove(KEY_MANUAL_WEB_COOKIE)
            .putBoolean(KEY_WEB_LOGGED_IN, false)
            .apply()
    }

    fun getEffectiveWebCookie(context: Context): String {
        val cmCookie = try {
            CookieManager.getInstance().getCookie("https://www.strava.com") ?: ""
        } catch (_: Exception) {
            ""
        }
        val savedCookie = getSavedWebCookie(context)
        return when {
            cmCookie.contains("_strava4_session") -> cmCookie
            savedCookie.isNotEmpty() -> savedCookie
            else -> cmCookie
        }
    }

    fun isWebSessionAvailable(context: Context): Boolean {
        val cookieStr = getEffectiveWebCookie(context)
        val hasSessionCookie = cookieStr.contains("_strava4_session") || cookieStr.contains("strava_remember")
        val flag = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_WEB_LOGGED_IN, false)
        return hasSessionCookie || flag
    }

    fun uploadRecordedRideAsync(
        context: Context,
        points: List<RecordedTrackPoint>,
        snapshot: LiveTelemetrySnapshot,
        title: String,
        description: String,
        visibility: String,
        callback: (Boolean, String) -> Unit
    ) {
        val appCtx = context.applicationContext
        executor.execute {
            if (!isWebSessionAvailable(appCtx)) {
                mainHandler.post {
                    callback(false, "Belum login ke Strava Web! Ketuk badge Strava di atas untuk login gratis.")
                }
                return@execute
            }

            val fitBytes = FitAndGpxEncoder.generateFitBinary(points, snapshot)
            val fitRes = tryUploadBytesBlocking(
                context = appCtx,
                fileBytes = fitBytes,
                fileExtension = "fit",
                mimeType = "application/octet-stream",
                sportType = snapshot.sportType,
                title = title,
                description = description,
                visibility = visibility
            )
            if (fitRes.first) {
                mainHandler.post { callback(true, fitRes.second) }
                return@execute
            }

            val gpxBytes = FitAndGpxEncoder.generateGpxXml(points, title, snapshot.sportType)
                .toByteArray(Charsets.UTF_8)
            val gpxRes = tryUploadBytesBlocking(
                context = appCtx,
                fileBytes = gpxBytes,
                fileExtension = "gpx",
                mimeType = "application/gpx+xml",
                sportType = snapshot.sportType,
                title = title,
                description = description,
                visibility = visibility
            )
            mainHandler.post {
                callback(gpxRes.first, if (gpxRes.first) gpxRes.second else fitRes.second)
            }
        }
    }

    private fun tryUploadBytesBlocking(
        context: Context,
        fileBytes: ByteArray,
        fileExtension: String,
        mimeType: String,
        sportType: String,
        title: String,
        description: String,
        visibility: String
    ): Pair<Boolean, String> {
        return try {
            try { CookieManager.getInstance().flush() } catch (_: Exception) {}
            val cookieStr = getEffectiveWebCookie(context)
            if (cookieStr.isEmpty()) {
                return Pair(false, "Sesi login web kosong. Silakan login ulang.")
            }

            val getConn = (URL("https://www.strava.com/upload/select").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                instanceFollowRedirects = true
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("Cookie", cookieStr)
                setRequestProperty("User-Agent", StravaWebLoginActivity.CLEAN_MOBILE_CHROME_UA)
            }
            val html = readStream(getConn)
            val finalUrl = getConn.url?.toString() ?: ""
            if (finalUrl.contains("/login") || finalUrl.contains("/session")) {
                return Pair(false, "Sesi Strava Web kedaluwarsa. Silakan login ulang.")
            }

            val q = '"'
            val csrfMarker = "name=" + q + "csrf-token" + q
            val contentPrefix = "content=" + q
            val csrfToken = if (html.contains(csrfMarker)) {
                html.substringAfter(csrfMarker).substringAfter(contentPrefix, "").substringBefore(q.toString(), "")
            } else ""

            if (csrfToken.isEmpty()) {
                return Pair(false, "CSRF Token Strava tidak ditemukan, silakan login ulang.")
            }

            val boundary = "----WebKitFormBoundary" + UUID.randomUUID().toString().replace("-", "")
            val lineEnd = "\r\n"
            val twoHyphens = "--"
            val fileName = "cyclotolow_${System.currentTimeMillis()}.$fileExtension"

            val postConn = (URL("https://www.strava.com/upload/files").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doInput = true
                doOutput = true
                useCaches = false
                instanceFollowRedirects = false
                connectTimeout = 20000
                readTimeout = 20000
                setRequestProperty("Cookie", cookieStr)
                setRequestProperty("X-CSRF-Token", csrfToken)
                setRequestProperty("X-Requested-With", "XMLHttpRequest")
                setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01")
                setRequestProperty("Origin", "https://www.strava.com")
                setRequestProperty("Referer", "https://www.strava.com/upload/select")
                setRequestProperty("User-Agent", StravaWebLoginActivity.CLEAN_MOBILE_CHROME_UA)
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            DataOutputStream(postConn.outputStream).use { dos ->
                fun writeField(name: String, value: String) {
                    dos.writeBytes(twoHyphens + boundary + lineEnd)
                    dos.writeBytes("Content-Disposition: form-data; name=\"$name\"$lineEnd")
                    dos.writeBytes(lineEnd)
                    dos.write(value.toByteArray(Charsets.UTF_8))
                    dos.writeBytes(lineEnd)
                }
                writeField("authenticity_token", csrfToken)
                writeField("sport_type", sportType)
                writeField("name", title)
                if (description.isNotEmpty()) writeField("description", description)

                dos.writeBytes(twoHyphens + boundary + lineEnd)
                dos.writeBytes("Content-Disposition: form-data; name=\"files[]\"; filename=\"$fileName\"$lineEnd")
                dos.writeBytes("Content-Type: $mimeType$lineEnd")
                dos.writeBytes(lineEnd)
                dos.write(fileBytes)
                dos.writeBytes(lineEnd)
                dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd)
                dos.flush()
            }

            val code = postConn.responseCode
            val postResp = readStream(postConn).trim()
            if (code !in 200..299 || postResp.startsWith("<!DOCTYPE", true)) {
                return Pair(false, "Gagal upload ke Strava (HTTP $code). Silakan login ulang.")
            }

            var uploadId = 0L
            try {
                if (postResp.startsWith("[")) {
                    val arr = JSONArray(postResp)
                    if (arr.length() > 0) uploadId = arr.getJSONObject(0).optLong("id", 0L)
                } else if (postResp.startsWith("{")) {
                    uploadId = JSONObject(postResp).optLong("id", 0L)
                }
            } catch (_: Exception) {}

            if (uploadId > 0L) {
                for (attempt in 1..6) {
                    Thread.sleep(1200L)
                    val progUrl = URL("https://www.strava.com/upload/progress?ids=$uploadId&new_uploader=1")
                    val progConn = (progUrl.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 10000
                        setRequestProperty("Cookie", cookieStr)
                        setRequestProperty("X-CSRF-Token", csrfToken)
                        setRequestProperty("X-Requested-With", "XMLHttpRequest")
                        setRequestProperty("User-Agent", StravaWebLoginActivity.CLEAN_MOBILE_CHROME_UA)
                    }
                    if (progConn.responseCode in 200..299) {
                        val progBody = readStream(progConn).trim()
                        val itemObj: JSONObject? = when {
                            progBody.startsWith("[") -> JSONArray(progBody).optJSONObject(0)
                            progBody.startsWith("{") -> {
                                val root = JSONObject(progBody)
                                root.optJSONArray("progress")?.optJSONObject(0) ?: root
                            }
                            else -> null
                        }
                        if (itemObj != null) {
                            val errVal = if (itemObj.isNull("error")) "" else itemObj.optString("error", "")
                            if (errVal.isNotEmpty() && errVal != "null") {
                                return Pair(false, "Strava menolak file: $errVal")
                            }
                            val actId = itemObj.optLong("activity_id", 0L).let {
                                if (it > 0L) it else itemObj.optJSONObject("activity")?.optLong("id", 0L) ?: 0L
                            }
                            if (actId > 0L) {
                                patchActivityDetails(cookieStr, csrfToken, actId, title, sportType, description, visibility)
                                return Pair(true, "Aktivitas #$actId berhasil tayang di Strava!")
                            }
                        }
                    }
                }
                return Pair(true, "Upload #$uploadId diterima Strava!")
            }
            Pair(true, "Berhasil Upload ke Strava!")
        } catch (e: Exception) {
            Pair(false, "Error jaringan: ${e.localizedMessage}")
        }
    }

    private fun patchActivityDetails(
        cookieStr: String,
        csrfToken: String,
        activityId: Long,
        title: String,
        sportType: String,
        description: String,
        visibility: String
    ) {
        try {
            val url = URL("https://www.strava.com/activities/$activityId")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                instanceFollowRedirects = false
                setRequestProperty("Cookie", cookieStr)
                setRequestProperty("X-CSRF-Token", csrfToken)
                setRequestProperty("X-Requested-With", "XMLHttpRequest")
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                setRequestProperty("User-Agent", StravaWebLoginActivity.CLEAN_MOBILE_CHROME_UA)
            }
            val form = "_method=patch" +
                "&authenticity_token=" + URLEncoder.encode(csrfToken, "UTF-8") +
                "&activity%5Bname%5D=" + URLEncoder.encode(title, "UTF-8") +
                "&activity%5Bdescription%5D=" + URLEncoder.encode(description, "UTF-8") +
                "&activity%5Bvisibility%5D=" + URLEncoder.encode(visibility, "UTF-8") +
                "&activity%5Bsport_type%5D=" + URLEncoder.encode(sportType, "UTF-8") +
                "&activity%5Btype%5D=" + URLEncoder.encode(sportType, "UTF-8")
            OutputStreamWriter(conn.outputStream).use { it.write(form) }
            conn.responseCode
        } catch (_: Exception) {}
    }

    private fun readStream(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        if (stream == null) return ""
        return BufferedReader(InputStreamReader(stream)).use { it.readText() }
    }
}
