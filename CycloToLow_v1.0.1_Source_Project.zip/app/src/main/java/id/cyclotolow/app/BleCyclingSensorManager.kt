package id.cyclotolow.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import java.util.UUID

data class BleDiscoveredDevice(
    val name: String,
    val address: String,
    val typeLabel: String,
    val device: BluetoothDevice
)

class BleCyclingSensorManager(private val context: Context) {

    companion object {
        val UUID_HR_SERVICE: UUID = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
        val UUID_HR_MEASUREMENT: UUID = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")

        val UUID_CSC_SERVICE: UUID = UUID.fromString("00001816-0000-1000-8000-00805f9b34fb")
        val UUID_CSC_MEASUREMENT: UUID = UUID.fromString("00002a5b-0000-1000-8000-00805f9b34fb")

        val UUID_CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val btAdapter: BluetoothAdapter? = btManager?.adapter
    private val handler = Handler(Looper.getMainLooper())

    private var activeGatt: BluetoothGatt? = null
    private var scanCallback: ScanCallback? = null

    @Volatile var connectedHrDeviceName: String = ""
        private set

    @Volatile var connectedCscDeviceName: String = ""
        private set

    @Volatile var latestBleHeartRateBpm: Int = 0
        private set

    @Volatile var latestBleCadenceRpm: Int = 0
        private set

    @Volatile var latestBleWheelSpeedMps: Double = 0.0
        private set

    private var lastHrPacketMs = 0L
    private var lastCscPacketMs = 0L

    private var prevWheelRevs: Long = -1L
    private var prevWheelEventTime: Int = -1
    private var prevCrankRevs: Int = -1
    private var prevCrankEventTime: Int = -1
    var wheelCircumferenceMeters: Double = 2.105

    fun getValidHeartRateBpm(): Int {
        return if (System.currentTimeMillis() - lastHrPacketMs < 10_000L) latestBleHeartRateBpm else 0
    }

    fun getValidCadenceRpm(): Int {
        return if (System.currentTimeMillis() - lastCscPacketMs < 8_000L) latestBleCadenceRpm else 0
    }

    fun getValidWheelSpeedMps(): Double {
        return if (System.currentTimeMillis() - lastCscPacketMs < 6_000L) latestBleWheelSpeedMps else 0.0
    }

    fun isBluetoothAvailable(): Boolean = btAdapter != null && btAdapter.isEnabled

    @SuppressLint("MissingPermission")
    fun startScan(onDeviceFound: (BleDiscoveredDevice) -> Unit, onScanFinished: () -> Unit) {
        val scanner = btAdapter?.bluetoothLeScanner
        if (scanner == null) {
            onScanFinished()
            return
        }
        stopScan()

        val seenAddresses = HashSet<String>()
        val filters = listOf(
            ScanFilter.Builder().setServiceUuid(ParcelUuid(UUID_HR_SERVICE)).build(),
            ScanFilter.Builder().setServiceUuid(ParcelUuid(UUID_CSC_SERVICE)).build()
        )
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult?) {
                val dev = result?.device ?: return
                val addr = dev.address ?: return
                if (!seenAddresses.add(addr)) return

                val uuids = result.scanRecord?.serviceUuids?.map { it.uuid } ?: emptyList()
                val typeLabel = when {
                    uuids.contains(UUID_HR_SERVICE) && uuids.contains(UUID_CSC_SERVICE) -> "HR + Cadence/Speed"
                    uuids.contains(UUID_HR_SERVICE) -> "Heart Rate (HRM)"
                    uuids.contains(UUID_CSC_SERVICE) -> "Speed / Cadence (CSC)"
                    else -> "BLE Sensor"
                }
                val devName = dev.name ?: result.scanRecord?.deviceName ?: "Sensor BLE ($addr)"
                handler.post {
                    onDeviceFound(BleDiscoveredDevice(devName, addr, typeLabel, dev))
                }
            }
        }

        try {
            scanner.startScan(filters, settings, scanCallback)
            handler.postDelayed({
                stopScan()
                onScanFinished()
            }, 9000L)
        } catch (_: Exception) {
            onScanFinished()
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        try {
            scanCallback?.let { btAdapter?.bluetoothLeScanner?.stopScan(it) }
        } catch (_: Exception) {
        }
        scanCallback = null
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(device: BluetoothDevice, onStatusChanged: (String) -> Unit) {
        stopScan()
        disconnect()

        val devName = device.name ?: device.address
        onStatusChanged("Menghubungkan ke $devName...")

        activeGatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    handler.post { onStatusChanged("Terhubung ke $devName, membaca layanan...") }
                    gatt.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connectedHrDeviceName = ""
                    connectedCscDeviceName = ""
                    latestBleHeartRateBpm = 0
                    latestBleCadenceRpm = 0
                    latestBleWheelSpeedMps = 0.0
                    handler.post { onStatusChanged("Sensor BLE terputus.") }
                }
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) return

                val hrChar = gatt.getService(UUID_HR_SERVICE)?.getCharacteristic(UUID_HR_MEASUREMENT)
                val cscChar = gatt.getService(UUID_CSC_SERVICE)?.getCharacteristic(UUID_CSC_MEASUREMENT)

                if (hrChar != null) {
                    connectedHrDeviceName = devName
                    enableNotification(gatt, hrChar)
                }
                if (cscChar != null) {
                    connectedCscDeviceName = devName
                    handler.postDelayed({ enableNotification(gatt, cscChar) }, 450L)
                }

                handler.post {
                    if (hrChar != null || cscChar != null) {
                        onStatusChanged("Aktif: $devName")
                    } else {
                        onStatusChanged("Perangkat tidak memiliki profil HR/CSC standar.")
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onCharacteristicChanged(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic
            ) {
                val data = characteristic.value ?: return
                when (characteristic.uuid) {
                    UUID_HR_MEASUREMENT -> parseHeartRatePacket(data)
                    UUID_CSC_MEASUREMENT -> parseCscPacket(data)
                }
            }
        })
    }

    @SuppressLint("MissingPermission")
    private fun enableNotification(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
        gatt.setCharacteristicNotification(characteristic, true)
        val desc = characteristic.getDescriptor(UUID_CCCD) ?: return
        desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        gatt.writeDescriptor(desc)
    }

    private fun parseHeartRatePacket(data: ByteArray) {
        if (data.size < 2) return
        val flags = data[0].toInt() and 0xFF
        val isUint16 = (flags and 0x01) != 0
        val bpm = if (isUint16 && data.size >= 3) {
            (data[1].toInt() and 0xFF) or ((data[2].toInt() and 0xFF) shl 8)
        } else {
            data[1].toInt() and 0xFF
        }
        if (bpm in 30..235) {
            latestBleHeartRateBpm = bpm
            lastHrPacketMs = System.currentTimeMillis()
        }
    }

    private fun parseCscPacket(data: ByteArray) {
        if (data.isEmpty()) return
        val flags = data[0].toInt() and 0xFF
        val hasWheel = (flags and 0x01) != 0
        val hasCrank = (flags and 0x02) != 0
        var offset = 1

        if (hasWheel && data.size >= offset + 6) {
            val wheelRevs = ((data[offset].toLong() and 0xFF)) or
                ((data[offset + 1].toLong() and 0xFF) shl 8) or
                ((data[offset + 2].toLong() and 0xFF) shl 16) or
                ((data[offset + 3].toLong() and 0xFF) shl 24)
            val wheelTime = (data[offset + 4].toInt() and 0xFF) or ((data[offset + 5].toInt() and 0xFF) shl 8)
            offset += 6

            if (prevWheelRevs >= 0 && wheelRevs >= prevWheelRevs && wheelTime != prevWheelEventTime) {
                val deltaRevs = wheelRevs - prevWheelRevs
                val deltaTimeTicks = (wheelTime - prevWheelEventTime) and 0xFFFF
                val deltaSec = deltaTimeTicks / 1024.0
                if (deltaSec > 0.1 && deltaRevs < 100) {
                    latestBleWheelSpeedMps = (deltaRevs * wheelCircumferenceMeters) / deltaSec
                    lastCscPacketMs = System.currentTimeMillis()
                }
            }
            prevWheelRevs = wheelRevs
            prevWheelEventTime = wheelTime
        }

        if (hasCrank && data.size >= offset + 4) {
            val crankRevs = (data[offset].toInt() and 0xFF) or ((data[offset + 1].toInt() and 0xFF) shl 8)
            val crankTime = (data[offset + 2].toInt() and 0xFF) or ((data[offset + 3].toInt() and 0xFF) shl 8)

            if (prevCrankRevs >= 0 && crankTime != prevCrankEventTime) {
                val deltaCranks = (crankRevs - prevCrankRevs) and 0xFFFF
                val deltaTimeTicks = (crankTime - prevCrankEventTime) and 0xFFFF
                val deltaSec = deltaTimeTicks / 1024.0
                if (deltaSec > 0.2 && deltaCranks in 1..30) {
                    val rpm = ((deltaCranks / deltaSec) * 60.0).toInt()
                    if (rpm in 15..200) {
                        latestBleCadenceRpm = rpm
                        lastCscPacketMs = System.currentTimeMillis()
                    }
                }
            }
            prevCrankRevs = crankRevs
            prevCrankEventTime = crankTime
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        try {
            activeGatt?.disconnect()
            activeGatt?.close()
        } catch (_: Exception) {
        }
        activeGatt = null
        connectedHrDeviceName = ""
        connectedCscDeviceName = ""
        latestBleHeartRateBpm = 0
        latestBleCadenceRpm = 0
        latestBleWheelSpeedMps = 0.0
    }
}
