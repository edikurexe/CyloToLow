package id.cyclotolow.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

class PhoneSensorHub(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val pressureSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE)
    private val tempSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
    private val stepDetectorSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
    private val linearAccelSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val rotationSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    val hasBarometer: Boolean get() = pressureSensor != null
    val hasAmbientTemp: Boolean get() = tempSensor != null
    val hasStepSensor: Boolean get() = stepDetectorSensor != null

    @Volatile var baroAltitudeMeters: Double? = null
        private set

    @Volatile var ambientTempC: Int? = null
        private set

    @Volatile var compassAzimuthDeg: Float = 0f
        private set

    @Volatile var isDevicePhysicallyMoving: Boolean = false
        private set

    private var smoothedPressureHpa: Double = 0.0
    private var seaLevelPressureHpa: Double = 1013.25
    private var baroCalibratedToGps = false

    private val recentStepTimestamps = ArrayDeque<Long>()
    private var lastMotionTimestampMs = 0L
    private var gravityEstimate = DoubleArray(3) { 0.0 }

    fun start() {
        pressureSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        tempSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        stepDetectorSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST)
        }
        linearAccelSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    fun calibrateBarometerWithGpsAltitude(gpsAltitudeMeters: Double, accuracyMeters: Float) {
        if (!hasBarometer || smoothedPressureHpa <= 300.0) return
        if (!baroCalibratedToGps && accuracyMeters <= 15f && gpsAltitudeMeters != 0.0) {
            val factor = (1.0 - (gpsAltitudeMeters / 44330.0)).coerceIn(0.5, 1.2)
            seaLevelPressureHpa = smoothedPressureHpa / factor.pow(5.255)
            baroCalibratedToGps = true
        }
    }

    fun getCurrentStepCadenceSpm(): Int {
        val now = System.currentTimeMillis()
        synchronized(recentStepTimestamps) {
            while (recentStepTimestamps.isNotEmpty() && now - recentStepTimestamps.first() > 8000L) {
                recentStepTimestamps.removeFirst()
            }
            if (recentStepTimestamps.size < 2) return 0
            val spanSec = (recentStepTimestamps.last() - recentStepTimestamps.first()) / 1000.0
            if (spanSec < 1.0) return 0
            val spm = ((recentStepTimestamps.size - 1) / spanSec) * 60.0
            return spm.toInt().coerceIn(30, 230)
        }
    }

    fun getAvailableSensorsSummary(): String {
        val list = mutableListOf("GPS")
        if (hasBarometer) list.add("Barometer")
        if (hasAmbientTemp) list.add("Termometer")
        if (hasStepSensor) list.add("Pedometer")
        if (linearAccelSensor != null) list.add("Akselerometer")
        if (rotationSensor != null) list.add("Kompas")
        return list.joinToString(" • ")
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val e = event ?: return
        val now = System.currentTimeMillis()
        when (e.sensor.type) {
            Sensor.TYPE_PRESSURE -> {
                val hpa = e.values[0].toDouble()
                if (hpa in 300.0..1100.0) {
                    smoothedPressureHpa = if (smoothedPressureHpa == 0.0) hpa else (smoothedPressureHpa * 0.85 + hpa * 0.15)
                    val alt = 44330.0 * (1.0 - (smoothedPressureHpa / seaLevelPressureHpa).pow(1.0 / 5.255))
                    baroAltitudeMeters = alt
                }
            }
            Sensor.TYPE_AMBIENT_TEMPERATURE -> {
                val c = e.values[0].toInt()
                if (c in -30..60) {
                    ambientTempC = c
                }
            }
            Sensor.TYPE_STEP_DETECTOR -> {
                synchronized(recentStepTimestamps) {
                    recentStepTimestamps.addLast(now)
                }
                lastMotionTimestampMs = now
                isDevicePhysicallyMoving = true
            }
            Sensor.TYPE_LINEAR_ACCELERATION -> {
                val mag = sqrt(
                    e.values[0] * e.values[0] +
                        e.values[1] * e.values[1] +
                        e.values[2] * e.values[2]
                )
                if (mag > 0.65f) {
                    lastMotionTimestampMs = now
                }
                isDevicePhysicallyMoving = (now - lastMotionTimestampMs) < 3500L
            }
            Sensor.TYPE_ACCELEROMETER -> {
                val alpha = 0.8
                gravityEstimate[0] = alpha * gravityEstimate[0] + (1 - alpha) * e.values[0]
                gravityEstimate[1] = alpha * gravityEstimate[1] + (1 - alpha) * e.values[1]
                gravityEstimate[2] = alpha * gravityEstimate[2] + (1 - alpha) * e.values[2]
                val lx = e.values[0] - gravityEstimate[0]
                val ly = e.values[1] - gravityEstimate[1]
                val lz = e.values[2] - gravityEstimate[2]
                val mag = sqrt(lx * lx + ly * ly + lz * lz)
                if (abs(mag) > 0.75) {
                    lastMotionTimestampMs = now
                }
                isDevicePhysicallyMoving = (now - lastMotionTimestampMs) < 3500L
            }
            Sensor.TYPE_ROTATION_VECTOR -> {
                val rotMatrix = FloatArray(9)
                val orientation = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(rotMatrix, e.values)
                SensorManager.getOrientation(rotMatrix, orientation)
                val deg = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
                compassAzimuthDeg = deg
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
