package id.cyclotolow.app

import android.Manifest
import android.content.BatteryManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_UI = "cyclotolow_ui_prefs"
        private const val KEY_DARK_MODE = "is_dark_mode"
        private const val KEY_BIKE_NAME = "bike_name"
        private const val KEY_TOTAL_MASS_KG = "total_mass_kg"
        private const val KEY_HISTORY_JSON = "ride_history_json"
    }

    private lateinit var rootContainer: LinearLayout
    private lateinit var topStatusBar: LinearLayout
    private lateinit var tvAppHeaderTitle: TextView
    private lateinit var tvTopGpsChip: TextView
    private lateinit var tvTopBatteryChip: TextView
    private lateinit var btnToggleTheme: Button

    // Navigation Views
    private lateinit var viewPreRide: ScrollView
    private lateinit var viewActiveRide: LinearLayout
    private lateinit var viewHistory: LinearLayout
    private lateinit var viewSettings: ScrollView
    private lateinit var bottomNavBar: LinearLayout
    private lateinit var navRide: Button
    private lateinit var navHistory: Button
    private lateinit var navSettings: Button

    // Pre-Ride Views
    private lateinit var cardPreRideBike: LinearLayout
    private lateinit var cardPreRideReadiness: LinearLayout
    private lateinit var cardPreRideRoute: LinearLayout
    private lateinit var tvPreRideProfileTitle: TextView
    private lateinit var tvPreRideGpsDetail: TextView
    private lateinit var tvPreRideSensorsDetail: TextView
    private lateinit var btnPreRideStrava: Button
    private lateinit var tvPreRideRouteName: TextView

    // Active Ride Views
    private lateinit var btnTabDataPage: Button
    private lateinit var btnTabMapPage: Button
    private lateinit var tvActiveBanner: TextView
    private lateinit var pageDataGrid: LinearLayout
    private lateinit var pageMapView: FrameLayout

    private lateinit var cellSpeedHero: LinearLayout
    private lateinit var cellDistance: LinearLayout
    private lateinit var cellMovingTime: LinearLayout
    private lateinit var cellAvgSpeed: LinearLayout
    private lateinit var cellElevGrade: LinearLayout
    private lateinit var cellHr: LinearLayout
    private lateinit var cellCadence: LinearLayout
    private lateinit var cellPower: LinearLayout
    private lateinit var rideControlBar: LinearLayout

    private lateinit var tvGridSpeed: TextView
    private lateinit var tvGridDistance: TextView
    private lateinit var tvGridTime: TextView
    private lateinit var tvGridAvgMax: TextView
    private lateinit var tvGridElevGrade: TextView
    private lateinit var tvGridHr: TextView
    private lateinit var tvGridCadence: TextView
    private lateinit var tvGridPower: TextView

    private lateinit var tvMapHudSpeed: TextView
    private lateinit var tvMapHudDist: TextView
    private lateinit var tvMapHudTime: TextView
    private lateinit var btnPauseResumeRide: Button

    // History & Settings
    private lateinit var tvHistoryHeader: TextView
    private lateinit var historyListContainer: LinearLayout
    private lateinit var tvSettingsHeader: TextView

    private lateinit var mapView: MapView
    private var livePolyline: Polyline? = null
    private var guidePolyline: Polyline? = null
    private var riderMarker: Marker? = null

    private var rideService: RideRecordingService? = null
    private var isBound = false
    private var isDarkTheme = false
    private var activeBottomTab = 0 // 0=Ride, 1=History, 2=Settings
    private var activeRideSubPage = 0 // 0=DataGrid, 1=MapView
    private var followUserMap = true
    private var currentSport = "Ride"
    private var bikeName = "Polygon Strattos"
    private var totalMassKg = 72.0

    private var pendingExportPoints: List<RecordedTrackPoint> = emptyList()
    private var pendingExportSnapshot: LiveTelemetrySnapshot? = null

    private val pickGuideGpxLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) loadGuideGpxOverlay(uri)
    }

    private val exportFitLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val snap = pendingExportSnapshot
        if (uri != null && pendingExportPoints.size >= 2 && snap != null) {
            Thread {
                try {
                    val bytes = FitAndGpxEncoder.generateFitBinary(pendingExportPoints, snap)
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    runOnUiThread { Toast.makeText(this, "File .FIT tersimpan!", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "Gagal simpan FIT: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    private val exportGpxLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/gpx+xml")
    ) { uri: Uri? ->
        if (uri != null && pendingExportPoints.size >= 2) {
            Thread {
                try {
                    val xml = FitAndGpxEncoder.generateGpxXml(pendingExportPoints, "CycloToLow $currentSport", currentSport)
                    contentResolver.openOutputStream(uri)?.use { it.write(xml.toByteArray(Charsets.UTF_8)) }
                    runOnUiThread { Toast.makeText(this, "File .GPX tersimpan!", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "Gagal simpan GPX: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as RideRecordingService.LocalBinder
            rideService = binder.getService().apply {
                sportType = currentSport
                totalSystemMassKg = totalMassKg
                onSnapshotUpdated = { snap -> runOnUiThread { updateUiFromSnapshot(snap) } }
            }
            isBound = true
            rideService?.let { updateUiFromSnapshot(it.buildSnapshot()) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            rideService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences(PREFS_UI, Context.MODE_PRIVATE)
        isDarkTheme = prefs.getBoolean(KEY_DARK_MODE, false)
        bikeName = prefs.getString(KEY_BIKE_NAME, "Polygon Strattos") ?: "Polygon Strattos"
        totalMassKg = prefs.getFloat(KEY_TOTAL_MASS_KG, 72.0f).toDouble()

        bindViews()
        setupMap()
        setupListeners()
        applyDualThemeColors()
        switchBottomTab(0)
        requestAllPermissions()

        val svcIntent = Intent(this, RideRecordingService::class.java)
        startService(svcIntent)
        bindService(svcIntent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun bindViews() {
        rootContainer = findViewById(R.id.rootContainer)
        topStatusBar = findViewById(R.id.topStatusBar)
        tvAppHeaderTitle = findViewById(R.id.tvAppHeaderTitle)
        tvTopGpsChip = findViewById(R.id.tvTopGpsChip)
        tvTopBatteryChip = findViewById(R.id.tvTopBatteryChip)
        btnToggleTheme = findViewById(R.id.btnToggleTheme)

        viewPreRide = findViewById(R.id.viewPreRide)
        viewActiveRide = findViewById(R.id.viewActiveRide)
        viewHistory = findViewById(R.id.viewHistory)
        viewSettings = findViewById(R.id.viewSettings)
        bottomNavBar = findViewById(R.id.bottomNavBar)
        navRide = findViewById(R.id.navRide)
        navHistory = findViewById(R.id.navHistory)
        navSettings = findViewById(R.id.navSettings)

        cardPreRideBike = findViewById(R.id.cardPreRideBike)
        cardPreRideReadiness = findViewById(R.id.cardPreRideReadiness)
        cardPreRideRoute = findViewById(R.id.cardPreRideRoute)
        tvPreRideProfileTitle = findViewById(R.id.tvPreRideProfileTitle)
        tvPreRideGpsDetail = findViewById(R.id.tvPreRideGpsDetail)
        tvPreRideSensorsDetail = findViewById(R.id.tvPreRideSensorsDetail)
        btnPreRideStrava = findViewById(R.id.btnPreRideStrava)
        tvPreRideRouteName = findViewById(R.id.tvPreRideRouteName)

        btnTabDataPage = findViewById(R.id.btnTabDataPage)
        btnTabMapPage = findViewById(R.id.btnTabMapPage)
        tvActiveBanner = findViewById(R.id.tvActiveBanner)
        pageDataGrid = findViewById(R.id.pageDataGrid)
        pageMapView = findViewById(R.id.pageMapView)

        cellSpeedHero = findViewById(R.id.cellSpeedHero)
        cellDistance = findViewById(R.id.cellDistance)
        cellMovingTime = findViewById(R.id.cellMovingTime)
        cellAvgSpeed = findViewById(R.id.cellAvgSpeed)
        cellElevGrade = findViewById(R.id.cellElevGrade)
        cellHr = findViewById(R.id.cellHr)
        cellCadence = findViewById(R.id.cellCadence)
        cellPower = findViewById(R.id.cellPower)
        rideControlBar = findViewById(R.id.rideControlBar)

        tvGridSpeed = findViewById(R.id.tvGridSpeed)
        tvGridDistance = findViewById(R.id.tvGridDistance)
        tvGridTime = findViewById(R.id.tvGridTime)
        tvGridAvgMax = findViewById(R.id.tvGridAvgMax)
        tvGridElevGrade = findViewById(R.id.tvGridElevGrade)
        tvGridHr = findViewById(R.id.tvGridHr)
        tvGridCadence = findViewById(R.id.tvGridCadence)
        tvGridPower = findViewById(R.id.tvGridPower)

        tvMapHudSpeed = findViewById(R.id.tvMapHudSpeed)
        tvMapHudDist = findViewById(R.id.tvMapHudDist)
        tvMapHudTime = findViewById(R.id.tvMapHudTime)
        btnPauseResumeRide = findViewById(R.id.btnPauseResumeRide)

        tvHistoryHeader = findViewById(R.id.tvHistoryHeader)
        historyListContainer = findViewById(R.id.historyListContainer)
        tvSettingsHeader = findViewById(R.id.tvSettingsHeader)

        mapView = findViewById(R.id.mapView)
    }

    private fun setupMap() {
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.controller.setZoom(16.0)
        mapView.controller.setCenter(GeoPoint(-7.1507, 111.8817))

        livePolyline = Polyline().apply {
            outlinePaint.color = Color.parseColor("#FC4C02")
            outlinePaint.strokeWidth = 10f
        }
        mapView.overlays.add(livePolyline)

        riderMarker = Marker(mapView).apply {
            title = "Posisi Saat Ini"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        }
        mapView.overlays.add(riderMarker)
    }

    private fun setupListeners() {
        btnToggleTheme.setOnClickListener {
            isDarkTheme = !isDarkTheme
            getSharedPreferences(PREFS_UI, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_DARK_MODE, isDarkTheme)
                .apply()
            applyDualThemeColors()
        }

        navRide.setOnClickListener { switchBottomTab(0) }
        navHistory.setOnClickListener {
            renderHistoryList()
            switchBottomTab(1)
        }
        navSettings.setOnClickListener { switchBottomTab(2) }

        btnTabDataPage.setOnClickListener { switchRideSubPage(0) }
        btnTabMapPage.setOnClickListener { switchRideSubPage(1) }

        findViewById<Button>(R.id.btnPreRideChangeSport).setOnClickListener {
            val sports = arrayOf("🚴 Road Cycling (Ride)", "🏃 Running (Run)", "🚶 Walking (Walk)")
            AlertDialog.Builder(this)
                .setTitle("Pilih Profil Aktivitas")
                .setItems(sports) { _, which ->
                    currentSport = when (which) {
                        1 -> "Run"
                        2 -> "Walk"
                        else -> "Ride"
                    }
                    rideService?.sportType = currentSport
                    updateProfileLabel()
                }
                .show()
        }

        findViewById<Button>(R.id.btnPreRideBle).setOnClickListener { showBleSensorDialog() }
        btnPreRideStrava.setOnClickListener {
            startActivity(Intent(this, StravaWebLoginActivity::class.java))
        }
        findViewById<Button>(R.id.btnPreRideLoadGpx).setOnClickListener {
            pickGuideGpxLauncher.launch(arrayOf("*/*"))
        }

        findViewById<Button>(R.id.btnStartRideMain).setOnClickListener {
            val svc = rideService ?: return@setOnClickListener
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestAllPermissions()
                return@setOnClickListener
            }
            livePolyline?.setPoints(emptyList())
            svc.startNewRide()
            switchBottomTab(0)
            switchRideSubPage(0)
            updateUiFromSnapshot(svc.buildSnapshot())
        }

        findViewById<Button>(R.id.btnLapRide).setOnClickListener {
            val lap = rideService?.markNextLap() ?: 1
            Toast.makeText(this, "Lap $lap ditandai!", Toast.LENGTH_SHORT).show()
        }

        btnPauseResumeRide.setOnClickListener {
            val svc = rideService ?: return@setOnClickListener
            svc.toggleManualPause()
            updateUiFromSnapshot(svc.buildSnapshot())
        }

        findViewById<Button>(R.id.btnFinishRide).setOnClickListener {
            val svc = rideService ?: return@setOnClickListener
            val snap = svc.buildSnapshot()
            AlertDialog.Builder(this)
                .setTitle("Selesaikan Aktivitas?")
                .setMessage(
                    String.format(
                        Locale.US,
                        "Jarak: %.2f km • Moving Time: %s\nAvg Speed: %.1f km/j",
                        snap.totalDistanceMeters / 1000.0,
                        formatHms(snap.movingTimeSec),
                        snap.avgSpeedKmh
                    )
                )
                .setPositiveButton("Selesai & Simpan") { _, _ ->
                    val finalSnap = svc.buildSnapshot()
                    val pts = svc.stopAndFinalizeRide()
                    updateUiFromSnapshot(svc.buildSnapshot())
                    if (pts.size >= 2) {
                        showPostRideSummaryDialog(pts, finalSnap)
                    } else {
                        Toast.makeText(this, "Titik GPS terlalu sedikit untuk disimpan.", Toast.LENGTH_LONG).show()
                    }
                }
                .setNeutralButton("Buang (Discard)") { _, _ ->
                    svc.stopAndFinalizeRide()
                    updateUiFromSnapshot(svc.buildSnapshot())
                    Toast.makeText(this, "Aktivitas dibuang.", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Lanjut", null)
                .show()
        }

        findViewById<Button>(R.id.btnCenterGps).setOnClickListener {
            followUserMap = true
            val snap = rideService?.buildSnapshot()
            if (snap?.latestLat != null && snap.latestLon != null) {
                mapView.controller.setZoom(16.5)
                mapView.controller.animateTo(GeoPoint(snap.latestLat, snap.latestLon))
            }
        }

        // Settings buttons
        findViewById<Button>(R.id.btnSettingsStravaLogin).setOnClickListener {
            startActivity(Intent(this, StravaWebLoginActivity::class.java))
        }
        findViewById<Button>(R.id.btnSettingsHrConsent).setOnClickListener {
            val intent = Intent(this, StravaWebLoginActivity::class.java).apply {
                putExtra(StravaWebLoginActivity.EXTRA_TARGET_URL, StravaWebLoginActivity.URL_STRAVA_HR_CONSENT)
            }
            startActivity(intent)
        }
        findViewById<Button>(R.id.btnSettingsBleScan).setOnClickListener { showBleSensorDialog() }
        findViewById<Button>(R.id.btnSettingsRiderWeight).setOnClickListener { showBikeAndWeightDialog() }
        findViewById<Button>(R.id.btnSettingsLogout).setOnClickListener {
            StravaWebUploader.clearWebSession(this)
            refreshStravaStatus()
            Toast.makeText(this, "Sesi Strava dihapus.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyDualThemeColors() {
        val bgMain = if (isDarkTheme) Color.parseColor("#0B0F19") else Color.parseColor("#F1F5F9")
        val bgCard = if (isDarkTheme) Color.parseColor("#141B2D") else Color.parseColor("#FFFFFF")
        val textPrimary = if (isDarkTheme) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
        val textSecondary = if (isDarkTheme) Color.parseColor("#94A3B8") else Color.parseColor("#475569")

        rootContainer.setBackgroundColor(bgMain)
        topStatusBar.setBackgroundColor(bgCard)
        bottomNavBar.setBackgroundColor(bgCard)
        rideControlBar.setBackgroundColor(bgCard)

        tvAppHeaderTitle.setTextColor(textPrimary)
        tvPreRideProfileTitle.setTextColor(textPrimary)
        tvPreRideGpsDetail.setTextColor(textPrimary)
        tvPreRideSensorsDetail.setTextColor(textPrimary)
        tvPreRideRouteName.setTextColor(textSecondary)
        tvHistoryHeader.setTextColor(textPrimary)
        tvSettingsHeader.setTextColor(textPrimary)

        val cards = listOf(
            cardPreRideBike, cardPreRideReadiness, cardPreRideRoute,
            cellSpeedHero, cellDistance, cellMovingTime, cellAvgSpeed,
            cellElevGrade, cellHr, cellCadence, cellPower
        )
        for (c in cards) c.setBackgroundColor(bgCard)

        tvGridSpeed.setTextColor(textPrimary)
        tvGridDistance.setTextColor(textPrimary)
        tvGridTime.setTextColor(textPrimary)

        btnToggleTheme.text = if (isDarkTheme) "☀️" else "🌙"
        btnToggleTheme.backgroundTintList = ColorStateList.valueOf(
            if (isDarkTheme) Color.parseColor("#1E293B") else Color.parseColor("#E2E8F0")
        )
        updateProfileLabel()
    }

    private fun updateProfileLabel() {
        val icon = when (currentSport) {
            "Run" -> "🏃 Running"
            "Walk" -> "🚶 Walking"
            else -> "🚴 Road Cycling • $bikeName"
        }
        tvPreRideProfileTitle.text = icon
    }

    private fun switchBottomTab(tabIndex: Int) {
        activeBottomTab = tabIndex
        val isRec = rideService?.buildSnapshot()?.isRecording == true

        viewPreRide.visibility = if (tabIndex == 0 && !isRec) View.VISIBLE else View.GONE
        viewActiveRide.visibility = if (tabIndex == 0 && isRec) View.VISIBLE else View.GONE
        viewHistory.visibility = if (tabIndex == 1) View.VISIBLE else View.GONE
        viewSettings.visibility = if (tabIndex == 2) View.VISIBLE else View.GONE

        bottomNavBar.visibility = if (isRec) View.GONE else View.VISIBLE

        val activeColor = Color.parseColor("#FC4C02")
        val inactiveColor = Color.parseColor("#64748B")
        navRide.setTextColor(if (tabIndex == 0) activeColor else inactiveColor)
        navHistory.setTextColor(if (tabIndex == 1) activeColor else inactiveColor)
        navSettings.setTextColor(if (tabIndex == 2) activeColor else inactiveColor)
    }

    private fun switchRideSubPage(subIndex: Int) {
        activeRideSubPage = subIndex
        pageDataGrid.visibility = if (subIndex == 0) View.VISIBLE else View.GONE
        pageMapView.visibility = if (subIndex == 1) View.VISIBLE else View.GONE

        btnTabDataPage.backgroundTintList = ColorStateList.valueOf(
            if (subIndex == 0) Color.parseColor("#FC4C02") else Color.parseColor("#CBD5E1")
        )
        btnTabDataPage.setTextColor(if (subIndex == 0) Color.WHITE else Color.parseColor("#0F172A"))

        btnTabMapPage.backgroundTintList = ColorStateList.valueOf(
            if (subIndex == 1) Color.parseColor("#FC4C02") else Color.parseColor("#CBD5E1")
        )
        btnTabMapPage.setTextColor(if (subIndex == 1) Color.WHITE else Color.parseColor("#0F172A"))
    }

    private fun updateUiFromSnapshot(snap: LiveTelemetrySnapshot) {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(1, 100)
        tvTopBatteryChip.text = "🔋 $batPct%"

        tvTopGpsChip.text = when {
            snap.gpsAccuracyMeters <= 12f -> "🛰️ OK (${snap.gpsAccuracyMeters.roundToInt()}m)"
            snap.gpsAccuracyMeters <= 25f -> "🛰️ ~${snap.gpsAccuracyMeters.roundToInt()}m"
            else -> "🛰️ No Fix"
        }

        // Switch Pre-Ride vs Active Ride automatically
        if (activeBottomTab == 0) {
            viewPreRide.visibility = if (snap.isRecording) View.GONE else View.VISIBLE
            viewActiveRide.visibility = if (snap.isRecording) View.VISIBLE else View.GONE
            bottomNavBar.visibility = if (snap.isRecording) View.GONE else View.VISIBLE
        }

        // Pre-Ride details
        tvPreRideGpsDetail.text = if (snap.gpsAccuracyMeters <= 25f) {
            "🛰️ GPS Siap (Akurasi ${snap.gpsAccuracyMeters.roundToInt()}m)"
        } else {
            "🛰️ GPS: Mencari sinyal satelit di area terbuka..."
        }
        val sensorSummary = rideService?.sensorHub?.getAvailableSensorsSummary() ?: "GPS"
        val bleInfo = listOf(snap.bleHrDeviceName, snap.bleCscDeviceName).filter { it.isNotEmpty() }.joinToString(", ")
        tvPreRideSensorsDetail.text = if (bleInfo.isNotEmpty()) {
            "📟 Sensor: $sensorSummary + BLE ($bleInfo)"
        } else {
            "📟 Sensor HP: $sensorSummary"
        }

        // Active Ride Grid
        tvGridSpeed.text = String.format(Locale.US, "%.1f", snap.currentSpeedKmh)
        tvGridDistance.text = String.format(Locale.US, "%.2f", snap.totalDistanceMeters / 1000.0)
        tvGridTime.text = formatHms(snap.movingTimeSec)
        tvGridAvgMax.text = String.format(Locale.US, "%.1f / %.1f", snap.avgSpeedKmh, snap.maxSpeedKmh)
        tvGridElevGrade.text = String.format(Locale.US, "+%dm • %.1f%%", snap.totalAscentMeters, snap.currentGradePercent)
        tvGridHr.text = if (snap.currentHeartRateBpm > 0) "${snap.currentHeartRateBpm}" else "--"
        tvGridCadence.text = if (snap.currentCadenceRpm > 0) "${snap.currentCadenceRpm}" else "--"
        tvGridPower.text = "${snap.currentPowerWatts} W"

        // Map HUD
        tvMapHudSpeed.text = String.format(Locale.US, "%.1f km/j", snap.currentSpeedKmh)
        tvMapHudDist.text = String.format(Locale.US, "%.2f km", snap.totalDistanceMeters / 1000.0)
        tvMapHudTime.text = formatHms(snap.movingTimeSec)

        when {
            snap.isPaused -> {
                tvActiveBanner.text = "PAUSED • LAP ${snap.lapCount}"
                tvActiveBanner.setBackgroundColor(Color.parseColor("#F59E0B"))
                btnPauseResumeRide.text = "▶ RESUME"
                btnPauseResumeRide.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#10B981"))
            }
            snap.isAutoPaused -> {
                tvActiveBanner.text = "AUTO-PAUSED (STOPPED) • LAP ${snap.lapCount}"
                tvActiveBanner.setBackgroundColor(Color.parseColor("#D97706"))
                btnPauseResumeRide.text = "⏸ PAUSE"
                btnPauseResumeRide.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
            }
            else -> {
                tvActiveBanner.text = "RECORDING • LAP ${snap.lapCount} • ${snap.temperatureC}°C"
                tvActiveBanner.setBackgroundColor(Color.parseColor("#10B981"))
                btnPauseResumeRide.text = "⏸ PAUSE"
                btnPauseResumeRide.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#F59E0B"))
            }
        }

        if (snap.latestLat != null && snap.latestLon != null) {
            val geo = GeoPoint(snap.latestLat, snap.latestLon)
            riderMarker?.position = geo
            if (followUserMap) mapView.controller.animateTo(geo)
        }
        val pts = rideService?.getRecordedPointsSnapshot() ?: emptyList()
        if (pts.size >= 2) {
            livePolyline?.setPoints(pts.map { GeoPoint(it.latitude, it.longitude) })
        }
        mapView.invalidate()
    }

    private fun showPostRideSummaryDialog(points: List<RecordedTrackPoint>, snap: LiveTelemetrySnapshot) {
        pendingExportPoints = points
        pendingExportSnapshot = snap

        val defaultTitle = when (snap.sportType) {
            "Run" -> "Morning Run"
            "Walk" -> "Morning Walk"
            else -> "Ride with CycloToLow"
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 24, 44, 12)
        }

        val tvStats = TextView(this).apply {
            text = String.format(
                Locale.US,
                "• Jarak: %.2f km\n" +
                    "• Moving Time: %s (Elapsed: %s)\n" +
                    "• Avg / Max Speed: %.1f / %.1f km/j\n" +
                    "• Elevation Gain: +%d m\n" +
                    "• Avg Power / Kalori: %d W • %d kcal",
                snap.totalDistanceMeters / 1000.0,
                formatHms(snap.movingTimeSec),
                formatHms(snap.elapsedTimeSec),
                snap.avgSpeedKmh,
                snap.maxSpeedKmh,
                snap.totalAscentMeters,
                snap.avgPowerWatts,
                snap.totalCaloriesKcal
            )
            textSize = 13f
        }

        val etTitle = EditText(this).apply {
            hint = "Judul Aktivitas"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(defaultTitle)
        }
        val etDesc = EditText(this).apply {
            hint = "Catatan / Deskripsi (Opsional)"
            inputType = InputType.TYPE_CLASS_TEXT
        }

        container.addView(tvStats)
        container.addView(etTitle)
        container.addView(etDesc)

        AlertDialog.Builder(this)
            .setTitle("🏁 Ride Summary")
            .setView(ScrollView(this).apply { addView(container) })
            .setPositiveButton("🚀 Upload Strava") { _, _ ->
                val title = etTitle.text.toString().trim().ifEmpty { defaultTitle }
                val desc = etDesc.text.toString().trim()
                saveToLocalHistory(title, snap, uploaded = true)
                Toast.makeText(this, "⏳ Mengunggah ke Strava Web...", Toast.LENGTH_SHORT).show()
                StravaWebUploader.uploadRecordedRideAsync(
                    context = this,
                    points = points,
                    snapshot = snap,
                    title = title,
                    description = desc,
                    visibility = "everyone"
                ) { ok, msg ->
                    AlertDialog.Builder(this)
                        .setTitle(if (ok) "✅ Terunggah ke Strava!" else "⚠️ Gagal Upload")
                        .setMessage(msg)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            .setNeutralButton("💾 Ekspor .FIT / .GPX") { _, _ ->
                saveToLocalHistory(defaultTitle, snap, uploaded = false)
                val ts = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                AlertDialog.Builder(this)
                    .setTitle("Pilih Format")
                    .setItems(arrayOf("Garmin .FIT", "Garmin .GPX")) { _, which ->
                        if (which == 0) exportFitLauncher.launch("CycloToLow_$ts.fit")
                        else exportGpxLauncher.launch("CycloToLow_$ts.gpx")
                    }
                    .show()
            }
            .setNegativeButton("Simpan Lokal") { _, _ ->
                saveToLocalHistory(defaultTitle, snap, uploaded = false)
                Toast.makeText(this, "Disimpan ke tab History.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun saveToLocalHistory(title: String, snap: LiveTelemetrySnapshot, uploaded: Boolean) {
        val prefs = getSharedPreferences(PREFS_UI, Context.MODE_PRIVATE)
        val arr = try { JSONArray(prefs.getString(KEY_HISTORY_JSON, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val obj = JSONObject().apply {
            put("title", title)
            put("sport", snap.sportType)
            put("ts", System.currentTimeMillis())
            put("km", snap.totalDistanceMeters / 1000.0)
            put("movingSec", snap.movingTimeSec)
            put("avgKmh", snap.avgSpeedKmh)
            put("ascent", snap.totalAscentMeters)
            put("uploaded", uploaded)
        }
        val updated = JSONArray().apply { put(obj) }
        for (i in 0 until arr.length().coerceAtMost(30)) updated.put(arr.getJSONObject(i))
        prefs.edit().putString(KEY_HISTORY_JSON, updated.toString()).apply()
    }

    private fun renderHistoryList() {
        historyListContainer.removeAllViews()
        val prefs = getSharedPreferences(PREFS_UI, Context.MODE_PRIVATE)
        val arr = try { JSONArray(prefs.getString(KEY_HISTORY_JSON, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            val emptyTv = TextView(this).apply {
                text = "Belum ada riwayat aktivitas.\nTekan START RIDE di tab Ride untuk mulai merekam."
                textSize = 13f
                setTextColor(Color.parseColor("#64748B"))
                setPadding(8, 24, 8, 8)
            }
            historyListContainer.addView(emptyTv)
            return
        }
        val fmt = SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(if (isDarkTheme) Color.parseColor("#141B2D") else Color.WHITE)
                setPadding(28, 22, 28, 22)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 16 }
            }
            val tvTitle = TextView(this).apply {
                text = "${o.optString("title")} (${o.optString("sport")})"
                textSize = 14.5f
                setTextColor(if (isDarkTheme) Color.WHITE else Color.parseColor("#0F172A"))
                paint.isFakeBoldText = true
            }
            val tvMeta = TextView(this).apply {
                text = String.format(
                    Locale.US,
                    "%s\n%.2f km • %s • Avg %.1f km/j • +%dm",
                    fmt.format(Date(o.optLong("ts"))),
                    o.optDouble("km"),
                    formatHms(o.optDouble("movingSec")),
                    o.optDouble("avgKmh"),
                    o.optInt("ascent")
                )
                textSize = 12f
                setTextColor(Color.parseColor("#64748B"))
            }
            card.addView(tvTitle)
            card.addView(tvMeta)
            historyListContainer.addView(card)
        }
    }

    private fun showBikeAndWeightDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 24, 44, 12)
        }
        val etBike = EditText(this).apply {
            hint = "Nama Sepeda (contoh: Polygon Strattos)"
            setText(bikeName)
        }
        val etMass = EditText(this).apply {
            hint = "Berat Total Pengendara + Sepeda (kg)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(totalMassKg.toString())
        }
        layout.addView(etBike)
        layout.addView(etMass)

        AlertDialog.Builder(this)
            .setTitle("Profil Sepeda & Berat")
            .setView(layout)
            .setPositiveButton("Simpan") { _, _ ->
                bikeName = etBike.text.toString().trim().ifEmpty { "Polygon Strattos" }
                totalMassKg = etMass.text.toString().toDoubleOrNull()?.coerceIn(40.0, 180.0) ?: 72.0
                rideService?.totalSystemMassKg = totalMassKg
                getSharedPreferences(PREFS_UI, Context.MODE_PRIVATE).edit()
                    .putString(KEY_BIKE_NAME, bikeName)
                    .putFloat(KEY_TOTAL_MASS_KG, totalMassKg.toFloat())
                    .apply()
                updateProfileLabel()
                Toast.makeText(this, "Profil disimpan!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showBleSensorDialog() {
        val ble = rideService?.bleManager ?: return
        if (!ble.isBluetoothAvailable()) {
            Toast.makeText(this, "Aktifkan Bluetooth di HP terlebih dahulu!", Toast.LENGTH_LONG).show()
            return
        }
        val foundList = mutableListOf<BleDiscoveredDevice>()
        val labels = mutableListOf<String>()

        val dialogBuilder = AlertDialog.Builder(this)
            .setTitle("📡 Memindai Sensor BLE...")
            .setMessage("Pastikan sensor HR Strap atau Cadence Sensor aktif.")
            .setNegativeButton("Tutup") { _, _ -> ble.stopScan() }

        if (ble.connectedHrDeviceName.isNotEmpty() || ble.connectedCscDeviceName.isNotEmpty()) {
            dialogBuilder.setNeutralButton("Putuskan Sensor") { _, _ ->
                ble.disconnect()
                Toast.makeText(this, "Sensor BLE diputuskan.", Toast.LENGTH_SHORT).show()
            }
        }
        val scanDialog = dialogBuilder.show()

        ble.startScan(
            onDeviceFound = { dev ->
                foundList.add(dev)
                labels.add("${dev.name} • ${dev.typeLabel}")
                scanDialog.dismiss()
                AlertDialog.Builder(this)
                    .setTitle("Pilih Sensor BLE")
                    .setItems(labels.toTypedArray()) { _, idx ->
                        ble.connectToDevice(foundList[idx].device) { status ->
                            Toast.makeText(this, status, Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Batal") { _, _ -> ble.stopScan() }
                    .show()
            },
            onScanFinished = {
                if (foundList.isEmpty() && scanDialog.isShowing) {
                    scanDialog.setTitle("Sensor BLE Tidak Ditemukan")
                    scanDialog.setMessage("Putar crank sepeda atau basahi strap HR lalu pindai ulang.")
                }
            }
        )
    }

    private fun loadGuideGpxOverlay(uri: Uri) {
        Thread {
            try {
                val wps = contentResolver.openInputStream(uri)?.use {
                    FitAndGpxEncoder.parseGuideGpx(it)
                } ?: emptyList()
                runOnUiThread {
                    if (wps.size < 2) {
                        Toast.makeText(this, "File GPX tidak valid.", Toast.LENGTH_SHORT).show()
                    } else {
                        guidePolyline?.let { mapView.overlays.remove(it) }
                        val newGuide = Polyline().apply {
                            outlinePaint.color = Color.parseColor("#800284C7")
                            outlinePaint.strokeWidth = 8f
                            setPoints(wps.map { GeoPoint(it.latitude, it.longitude) })
                        }
                        guidePolyline = newGuide
                        mapView.overlays.add(0, newGuide)
                        mapView.controller.animateTo(GeoPoint(wps.first().latitude, wps.first().longitude))
                        mapView.invalidate()
                        tvPreRideRouteName.text = "Rute GPX dimuat (${wps.size} titik)"
                        Toast.makeText(this, "Rute panduan GPX siap!", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Gagal muat GPX: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun refreshStravaStatus() {
        val connected = StravaWebUploader.isWebSessionAvailable(this)
        btnPreRideStrava.text = if (connected) "🟢 Strava Terhubung" else "🔴 Login Strava"
    }

    private fun formatHms(secDouble: Double): String {
        val total = secDouble.roundToInt().coerceAtLeast(0)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    private fun requestAllPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) perms.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 202)
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        refreshStravaStatus()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        if (isBound) {
            unbindService(serviceConnection)
            isBound = false
        }
        super.onDestroy()
    }
}
